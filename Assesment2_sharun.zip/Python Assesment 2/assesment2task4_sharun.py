# program to find the number of odd and even numbers

l=int(input("Enter the limit:"))
even=[]
odd=[]

for i in range(l):
    num=int(input("Enter the values:"))
    if num%2==0:
        even.append(num)
    else:
        odd.append(num)

print("Number of even numbers:",len(even))
print("Number of odd numbers:",len(odd))