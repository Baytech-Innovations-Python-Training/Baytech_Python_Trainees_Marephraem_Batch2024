# program to find a number is strong or not


num=int(input("Enter the number"))
sum=0
n=num

while num>0:
    rem=num%10
    fac=1
    for i in range(1,rem+1):
        fac=fac*i
    sum=sum+fac
    num=num//10

if sum==n:
    print(n,"is a Strong number.")
else:
    print(n,"is not a Strong number.")