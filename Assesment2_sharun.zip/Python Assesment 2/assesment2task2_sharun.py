# program to find a number is prime or not


num=int(input("Enter the number:"))
sum=0

for i in range(1,num+1):
    if num%i==0:
        sum+=1

if sum==2:
    print(num,"is a prime number.")
else:
    print(num,"is not a prime number.")
