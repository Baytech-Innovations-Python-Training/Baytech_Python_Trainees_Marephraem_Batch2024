#program to find the value of one number raised to the power of another number

base=int(input("Enter the Base number:"))
pow=int(input("Enter the Power number:"))

res=1
while pow>0:
    res *=base
    pow-=1

print("Answer is:",res)
