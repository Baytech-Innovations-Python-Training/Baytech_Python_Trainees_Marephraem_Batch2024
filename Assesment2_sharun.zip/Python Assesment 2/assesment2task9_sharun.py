#program to find the number is perfect

num=int(input("Enter the number:"))
for i in range(1,num):
    if num%i==0:
        print(i)