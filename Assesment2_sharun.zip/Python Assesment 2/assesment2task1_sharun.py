#program to find the factor of a given number

x=int(input("Enter the number to get the fator:"))
for i in range(1,x+1):
    if x%i==0:
        print(i)
        