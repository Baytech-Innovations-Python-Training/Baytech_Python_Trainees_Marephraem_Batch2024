#program to find reverse of number using while loop

num=int(input("Enter the number:"))
n=num
sum=0

while num>0:
    rem=num%10
    sum=(sum*10)+rem
    num=num//10

print("Before number:",n)
print("Reverse number:",sum)


