#program to print a perfect number between 1-1000

num=1000
for i in range(1,1000):
    if num%i==0:
        print(i)