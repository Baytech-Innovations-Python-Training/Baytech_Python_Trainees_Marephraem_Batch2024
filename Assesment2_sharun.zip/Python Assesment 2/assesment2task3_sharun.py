#program to check a number is amstrong or not

num=int(input("Enter the number:"))
sum=0
temp=num

while num>0:
    rem=num%10
    sum=sum+(rem**3)
    num=num//10

if sum==temp:
    print(temp,"is a armstrong number.")
else:
    print(temp,"is not a armstrong number.")
