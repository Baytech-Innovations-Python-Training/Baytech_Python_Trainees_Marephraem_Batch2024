1.#gross salary
def calculate_gross_salary(basic_salary):
    if basic_salary < 1500:
        hra=0.10*basic_salary
        da=0.90*basic_salary
    else:
        hra=500
        da=0.98*basic_salary

    gross_salary=basic_salary+hra+da
    return gross_salary
#prompting input from the user
basic_salary=float(input("enter the basic salary:"))
gross_salary=calculate_gross_salary(basic_salary)
print("gross salary:",gross_salary)
2.#find factor
def find_factors(number):
    factors = []
    for i in range(1, number + 1):
        if number % i == 0:
            factors.append(i)
    return factors

num = int(input("Enter a number: "))
factors = find_factors(num)
print("the factors of given number", factors)
3.#reverse of n digit number
def reverse_number(n):
    reversed_num = 0
    while n > 0:
        reversed_num = reversed_num * 10 + n % 10
        n //= 10
    return reversed_num

num = int(input("Enter an integer: "))
reversed_num = reverse_number(num)
print("The reverse of num is ",reversed_num)
4.#fibonacci series
def fibonacci_series(n):
    fib_series = [0, 1]
    while fib_series[-1] + fib_series[-2] <= n:
        next_fib = fib_series[-1] + fib_series[-2]
        fib_series.append(next_fib)
    return fib_series

# Taking input from the user
limit = int(input("Enter the upper limit: "))
fibonacci_numbers = fibonacci_series(limit)

print("Fibonacci Series:")
for num in fibonacci_numbers:
    print(num, end=" ")
5.#largest number from a list
num_list = [int(x) for x in input("Enter a list of numbers separated by spaces: ").split()]
largest_number = max(num_list)

print(f"The largest number in the list is: {largest_number}")
6.#remove duplicate form a list
num_list = [int(x) for x in input("Enter a list of numbers separated by spaces: ").split()]
unique_numbers = list(set(num_list))

print("List with duplicates removed:", unique_numbers)
7.#program to clone or copy a list
original_list = [1, 2, 3, 4, 5]
copied_list = original_list[:]

print("Original list:", original_list)
print("Copied list:", copied_list)
8.#add space between potential words
def add_spaces(text):
    result = ""
    for char in text:
        if char.isupper() and result:
            result += " " + char
        else:
            result += char
    return result

input_text = input("Enter a string: ")
formatted_text = add_spaces(input_text)
print("Formatted string:", formatted_text)
9.#get the 4th element


def main():
    my_tuple = (1, 2, 3, 4, 5, 6, 7, 8, 9, 10)

    fourth_element = my_tuple[3]
    fourth_from_last = my_tuple[-4]

    print("Original Tuple:", my_tuple)
    print("4th Element:", fourth_element)
    print("4th Element from the end:", fourth_from_last)


if __name__ == "__main__":
    main()
10.#element exist within a tuple
def check_element_in_tuple(my_tuple, element):
    if element in my_tuple:
        return True
    else:
        return False

# Taking input from the user
my_tuple = tuple(input("Enter elements of the tuple separated by spaces: ").split())
element_to_check = input("Enter the element to check: ")

result = check_element_in_tuple(my_tuple, element_to_check)

if result:
    print(f"The element '{element_to_check}' exists in the tuple.")
else:
    print(f"The element '{element_to_check}' does not exist in the tuple.")
11.#convert a tuple to a dictionary
input_tuple = (("a", 1), ("b", 2), ("c", 3))
converted_dict = dict(input_tuple)

print("Converted dictionary:", converted_dict)
12.#Sort a tuple of tuples by 2nd item
input_tuple = ((3, 1), (1, 2), (2, 3))

sorted_tuple = tuple(sorted(input_tuple, key=lambda x: x[0]))
print("Sorted tuple of tuples:", sorted_tuple)
13.#to Convert Tuple to Set
def tuple_to_set(input_tuple):
    converted_set = set(input_tuple)
    return converted_set

# Taking input from the user
input_tuple = tuple(input("Enter elements of the tuple separated by spaces: ").split())
converted_set = tuple_to_set(input_tuple)

print("Converted Set:", converted_set)
14.#Check if a set is a subset, using comparison operators
def check_subset(super_set, sub_set):
    if sub_set <= super_set:  # sub_set is a subset of super_set
        return True
    else:
        return False

# Taking input from the user
super_set = set(input("Enter elements of the super set separated by spaces: ").split())
sub_set = set(input("Enter elements of the sub set separated by spaces: ").split())

is_subset = check_subset(super_set, sub_set)

if is_subset:
    print("The second set is a subset of the first set.")
else:
    print("The second set is not a subset of the first set.")
15.#.program to count number of vowels using sets in given string
def count_vowels(input_string):
    vowels = set("AEIOUaeiou")  # Creating a set of vowels
    vowel_count = 0

    for char in input_string:
        if char in vowels:
            vowel_count += 1

    return vowel_count

# Taking input from the user
input_string = input("Enter a string: ")
vowel_count = count_vowels(input_string)

print(f"Number of vowels in the string: {vowel_count}")
16.#to check whether a given key already exists in a dictionary
def check_key_in_dict(input_dict, key):
    if key in input_dict:
        return True
    else:
        return False

# Taking input from the user
input_dict = {"name": "John", "age": 30, "city": "New York"}
key_to_check = input("Enter the key to check: ")

key_exists = check_key_in_dict(input_dict, key_to_check)

if key_exists:
    print(f"The key '{key_to_check}' exists in the dictionary.")
else:
    print(f"The key '{key_to_check}' does not exist in the dictionary.")
17.#Write a program to sum all the values of a dictionary
def sum_dictionary_values(input_dict):
    total_sum = sum(input_dict.values())
    return total_sum

# Taking input from the user
input_dict = {
    "a": 10,
    "b": 20,
    "c": 30,
    "d": 40
}

total_sum = sum_dictionary_values(input_dict)

print(f"The sum of all values in the dictionary is: {total_sum}")





