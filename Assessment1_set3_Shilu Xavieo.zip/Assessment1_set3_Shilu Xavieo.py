#total expenses program in python
Quantity=int(input("enter the Quantity purchased :"))
Amount=int(input("enter the amount per item:"))
discount=10/100
if Quantity>10:
    TotalExpenses=(Quantity*Amount)
    TotalExpenses-(10/100)
    print("TotalExpenses:",TotalExpenses-TotalExpenses*10/100)
#company insures its drivers program
driver="shilu"
age=int(input("enter your age:"))
sex=input("enter your sex:")
martialstatus=input("enter your martialstatus:")
if martialstatus=='u' and age>30 and sex=='m':
     print("driver should be insured")
elif martialstatus=='u' and age>25 and sex=='f':
     print("driver should not be insured")
else:
    print("invalid")
#calculate the salary
gender=input("enter your gender:")
year=int(input("enter your year of service:"))
education=int(input("enter your level of education:"))
if gender=='m'and year>=10 and education==1:
    print("salary:",15000)
elif year>=10 and education==0:
    print("salary:",10000)
elif year<10 and education==1:
    print("salary:",9000)
else:
    print("salary:",7000)
    if gender=="f":
        if year>=10 and education==0:
            print("salary:",12000)
        elif year>=10 and education==0:
            print("salary:",9000)
        elif year<10 and education==1:
            print("salary:",10000)
        else:
            print("salary:",6000)
    
