num=int(input("Enter a number: "))
sum=0
temp=num
while(num>0):
    rem=num%10
    cube=rem**3
    sum=sum+cube
    num//=10
if(sum==temp):
    print(temp,"is a armstrong number")
else:
    print("it is not an armstrong number")
