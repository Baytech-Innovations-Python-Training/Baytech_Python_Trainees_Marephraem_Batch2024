x=int(input("enter a number: "))
sum=0
temp=x
while(temp>1):
    rem=temp%10
    sum=(sum*10)+rem
    temp=temp//10
print("The reverse number is: ",sum)