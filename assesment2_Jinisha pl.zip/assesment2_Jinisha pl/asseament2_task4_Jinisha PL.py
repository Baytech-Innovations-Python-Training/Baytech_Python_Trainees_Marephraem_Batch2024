limit=int(input("enter the limit:"))
array=[ ]
array_even=[]
array_odd=[]
for i in range(0,limit):
    num=int(input("Enter the values: "))
    array.append(num)
for j in range(0,len(array)):
    if(array[j]%2==0):
        array_even.append(array[j])
    elif(array[j]!=0):
        array_odd.append(array[j])
print("The array is: ",len(array))
print("The even array is: ",len(array_even))
print("The odd array is: ",len(array_odd))
