num=int(input("Enter a number: "))
for i in range(2,num+1):
    if(num%i!=0):
        print(num,"is prime")
    else:
        print("It is not a prime number...")