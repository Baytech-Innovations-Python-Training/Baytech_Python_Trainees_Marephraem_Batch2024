"""#1.If his basic salary is less than Rs. 1500, then HRA = 10% of basic salary and DA = 90% of 
#basic salary. If his salary is either equal to or above Rs. 1500, then HRA = Rs. 500 and DA = 
#98% of basic salary. If the employee's salary is input through the keyboard write a 
#program to find his gross salary

basic_salary=bs=float(input("Enter the basic salary:"))

if bs<1500:
    hra = 0.1 * bs
    da = 0.9 * bs
else:
    hra = 500
    da = 0.98 *bs

gross_salary =bs+ hra + da
print("Gross Salary:", gross_salary):

#2.Write a program to find the factor of the given number.

a=int(input("ENTER THE NUMBER:"))
for i in range(1,a+1):
    if a%i==0:
        print(i)
#3.Write a program to find the reverse of n digit number using While loop
number = int(input("Enter a number: "))
reverse = 0

while number > 0:
    digit = number % 10
    reverse = (reverse * 10) + digit
    number = number // 10
print(reverse)

#4.Write a program to find the Fibonacci Series of the given number.
number = int(input("Enter a number: "))

num1 = 0
num2 = 1
if number <= 0:
    print("Please enter a positive number.")
elif number == 1:
    print(num1)
else:
    print(num1, end=" ")
    print(num2, end=" ")
    while num2 + num1 <= number:
        fib = num1 + num2
        print(fib, end=" ")
        num1 = num2
        num2 = fib

#5.Write a Python program to get the largest number from a list

numbers = [5, 10, 3, 8, 15, 2]
largest = numbers[0]
for number in numbers:
    if number > largest:
        largest = number

print("Largest number:", largest)

#6.Write a Python program to remove duplicates from a list
numbers = [1, 2, 3, 4, 2, 3, 5, 6, 4]
unique_numbers = list(set(numbers))

print("List with duplicates removed:", unique_numbers)
#7.Write a Python program to clone or copy a list
original_list = [1, 2, 3, 4, 5]

cloned_list = original_list[:]

print("Original List:", original_list)
print("Cloned List:", cloned_list)

#9.Write a Python program to get the 4th element and 4th element from last of a tuple
my_tuple = ("apple", "banana", "cherry", "date", "elderberry", "fig")
fourth_element = my_tuple[3]

fourth_from_last_element = my_tuple[-4]

print("4th element:", fourth_element)
print("4th element from last:", fourth_from_last_element)
#10.Write a Python program to check whether an element exists within a tuple
my_tuple = ("apple", "banana", "cherry", "date", "elderberry", "fig")
element = input("Enter an element to check: ")

if element in my_tuple:
    print("Element exists in the tuple!")
else:
    print("Element does not exist in the tuple.")"""
#11.Write a Python program to convert a tuple to a dictionary
    
my_tuple = (("apple", 1), ("banana", 2), ("cherry", 3))

my_dict = dict(my_tuple)

print(my_dict)


#12.Sort a tuple of tuples by 2nd item
my_tuple = (("apple", 3), ("banana", 1), ("cherry", 2))

sorted_tuple = tuple(sorted(my_tuple, key=lambda x: x[1]))

print(sorted_tuple)

#13.Write a Python program to Convert Tuple to Set

my_tuple = ("apple", "banana", "cherry", "banana", "date", "cherry")
my_set = set(my_tuple)
print(my_set)
#14.Write a Python program to Check if a set is a subset, using comparison operator
set1 = {1, 2, 3, 4}
set2 = {2, 4}

if set2 <= set1:
    print("set2 is a subset of set1")
else:
    print("set2 is not a subset of set1")

#15.program to count number of vowels using sets in given string
def count_vowels(string):
    vowels = {'a', 'e', 'i', 'o', 'u'}
    count = 0
    for char in string:
        if char.lower() in vowels:
            count += 1
    return count

input_string = "Hello, World!"
vowel_count = count_vowels(input_string)
print("Number of vowels:", vowel_count)
#16.Write a Python program to check whether a given key already exists in a dictionary
def check_key(dictionary, key):
    if key in dictionary:
        return True
    else:
        return False

my_dict = {'name': 'John', 'age': 25, 'city': 'New York'}
key_to_check = 'age'
key_exists = check_key(my_dict, key_to_check)
print("Key exists:", key_exists)
























































#























































































