def is_prime(number):
    if number <= 1:
        return False
    for i in range(2, int(number**0.5) + 1):
        if number % i == 0:
            return False
    return True

if __name__ == "__main__":
    try:
        num = int(input("Enter a number: "))
        if is_prime(num):
            print("This is a Prime Number.")
        else:
            print("This is not a Prime Number.")
    except ValueError:
        print("Invalid input. Please enter a valid integer.")