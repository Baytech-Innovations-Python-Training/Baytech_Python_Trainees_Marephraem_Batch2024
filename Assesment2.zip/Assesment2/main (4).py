if __name__ == "__main__":
    try:
        limit = int(input("Enter the Limit: "))
        even = []
        odd = []

        for i in range(limit):
            value = int(input("Enter the Values: "))
            if value % 2 == 0:
                even.append(value)
            else:
                odd.append(value)

        print(f"Number of Even: {len(even)}")
        print(f"Number of Odd: {len(odd)}")

    except ValueError:
        print("Invalid input. Please enter a valid integer.")