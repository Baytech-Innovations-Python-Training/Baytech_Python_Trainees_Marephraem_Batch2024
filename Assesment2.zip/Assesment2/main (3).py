def is_armstrong_number(num):
    temp = num
    num_of_digits = len(str(num))
    sum = 0

    while temp > 0:
        digit = temp % 10
        sum += digit ** num_of_digits
        temp //= 10

    return sum == num

if __name__ == "__main__":
    try:
        num = int(input("Enter the Number: "))
        if is_armstrong_number(num):
            print(f"{num} is an Armstrong Number.")
        else:
            print(f"{num} is not an Armstrong Number.")
    except ValueError:
        print("Invalid input. Please enter a valid integer.")