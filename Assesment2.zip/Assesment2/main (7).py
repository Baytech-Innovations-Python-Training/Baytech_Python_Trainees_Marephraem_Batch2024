def power(base, pow):
    result = 1
    while pow > 0:
        result *= base
        pow -= 1
    return result

if __name__ == "__main__":
    try:
        base = int(input("Enter the Base Number: "))
        pow = int(input("Enter the Power Number: "))
        result = power(base, pow)
        print(f"Answer: {result}")
    except ValueError:
        print("Invalid input. Please enter valid integers for base and power.")