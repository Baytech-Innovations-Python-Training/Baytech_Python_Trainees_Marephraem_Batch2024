def find_divisors(x):
    print("Enter the Number:", x)
    for i in range(1, x + 1):
        if x % i == 0:
            print(i)

if __name__ =="__main__":
    try:
        num = int(input("Enter a number: "))
        find_divisors(num)
    except ValueError:
        print("Invalid input. Please enter a valid integer.")