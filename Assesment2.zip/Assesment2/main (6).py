def factorial(n):
    if n == 0:
        return 1
    else:
        return n * factorial(n - 1)

def is_strong_number(num):
    original_num = num
    total_sum = 0
    while num > 0:
        digit = num % 10
        total_sum += factorial(digit)
        num //= 10
    return total_sum == original_num

if __name__ == "__main__":
    try:
        num = int(input("Enter the Number: "))
        if is_strong_number(num):
            print(f"{num} is a Strong Number.")
        else:
            print(f"{num} is not a Strong Number.")
    except ValueError:
        print("Invalid input. Please enter a valid integer.")