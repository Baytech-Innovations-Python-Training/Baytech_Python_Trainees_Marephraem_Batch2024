def reverse_number(num):
    reversed_num = 0
    while num > 0:
        remainder = num % 10
        reversed_num = reversed_num * 10 + remainder
        num //= 10
    return reversed_num

if __name__ == "__main__":
    try:
        num = int(input("Enter the Number: "))
        reversed_num = reverse_number(num)
        print(f"Before Number: {num} Reverse Number: {reversed_num}")
    except ValueError:
        print("Invalid input. Please enter a valid integer.")