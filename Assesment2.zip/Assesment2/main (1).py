def is_perfect_number(num):
    divisors = []
    for i in range(1, num):
        if num % i == 0:
            divisors.append(i)
    return divisors


if __name__ == "__main__":
    try:
        num = int(input("Enter the Number: "))
        divisors = is_perfect_number(num)
        print(divisors)
    except ValueError:
        print("Invalid input. Please enter a valid integer.")