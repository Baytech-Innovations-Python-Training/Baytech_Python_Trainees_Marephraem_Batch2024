def find_divisors_sum(n):
    divisors_sum = 0
    for i in range(1,n):
        if n % i == 0:
            divisors_sum += i
    return divisors_sum
for num in range (1,1001):
    if num== find_divisors_sum(num):
        print(num)