                                # Population program in python
# Declaring variable
Population=80000 #it defines total population in the town
Total_Men=Population*52/100 # 52% of men
Total_Women=Population*48/100  # 48% of women
Total_Literacy=Population*48/100
Men_Literate=Population*35/100

print("Literacy Rate in TOWN\n")

print("Total Population : ",Population)
print("Total Mens : ",Total_Men)
print("Total Womens : ",Total_Women)
print("Total Literacy : ",Total_Literacy)
print("Total Literacy Mens : ",Men_Literate)
print("Total Literacy Womens : ",Population*13/100)
print("Total Not Literacy Mens : ",Total_Men-Men_Literate)
print("Total Not Literacy Womens : ",Total_Women-Population*13/100)






