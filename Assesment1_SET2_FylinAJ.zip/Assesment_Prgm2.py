# Currency Program in Python
amt=int(input("Enter the Amount to be Withdrawn : "))
hundred=amt//100
amt=amt%100
fifty=amt//50
amt=amt%50
Ten=amt//10

print("No. of Hundred Notes : ",hundred)
print("No. of Fifty Notes : ",fifty)
print("No of Ten Notes : ",Ten)
