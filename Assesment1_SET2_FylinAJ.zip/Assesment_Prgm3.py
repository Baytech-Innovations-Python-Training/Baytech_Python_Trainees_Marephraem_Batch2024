# Cost Price Per Item
sp=int(input("Enter Selling Price : ")) # entering the price of 15 items
profit=int(input("Enter the Profit : ")) #  enter your profit amount
cp=sp-profit
cp=cp//15

if profit>sp:
    print("Enter the profit Correctly (you wont get more profit than selling price, Think Twice)")
else:
    print("Cost Price of per ITEM : ", cp)
    print("YOU SUCCEED")