num=int(input("Enter the Number:"))
for i in range (1,num):
    if num%i==0:
       print (i)