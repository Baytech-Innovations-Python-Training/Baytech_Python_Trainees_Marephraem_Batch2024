#value of one number raised by power of other number
base=int(input("Enter the Base Number :"))
pow=int(input("Enter the Power Number:"))
res=1
while pow>0:
    res=res*base
    pow-=1
print ("Answer:",res)    
    
