#getting input from user
n = int(input("Enter a Number :"))
#digit is a
a = 0
temp=n
#finding the digit 
while temp != 0:
    temp//= 10
    a += 1
sum = 0
temp=n
#checking wether the input is armstrong number or not
while temp > 0:
   rem = temp % 10
   sum += rem ** a
   temp //= 10
#displaying the result
if n == sum:
   print(n,"is an Armstrong number")
else:
   print(n,"is not an Armstrong number")

