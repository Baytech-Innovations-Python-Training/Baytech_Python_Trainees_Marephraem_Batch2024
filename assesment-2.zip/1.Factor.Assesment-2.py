#finding the factor of a number
#getting the input number
x=int(input("Enter the Number :"))
#declaring the range from 1 to x+1
for i in range (1,x+1):
    #using if statement to find the divisor of x
    if x%i==0:
        #printing the divisors of x
        print (i)
