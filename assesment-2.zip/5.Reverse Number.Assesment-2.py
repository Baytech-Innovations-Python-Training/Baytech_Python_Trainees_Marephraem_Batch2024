#finding even and odd numbers
num=int(input("Enter the Number :"))
number=num
sum=0
while 0<number:
    rem=number%10
    sum=(sum*10)+rem
    number=number//10  
print ("Before Number :",num)
print ("After Number :",sum)

