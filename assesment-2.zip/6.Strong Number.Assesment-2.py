#finding strong number
num=int(input("Enter the Number :"))
number=num
sum=0
while num>0:
    rem=number%10
    fact=1
    for i in range(1,rem+1):
        fact=fact*i
    sum=sum+fact
    num=num//10
if sum==0:
    print (number,"IS a stong Number")
else:
    print (number,"IS not a stong Number")
