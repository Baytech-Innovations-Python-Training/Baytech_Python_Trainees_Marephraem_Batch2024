#finding the prime number
#getting the input
sum=1
n=int(input("Enter a Number :"))
#giving range from the 1 to the number
for i in range (1,n):
    if n%i==0:
        sum+=1
if sum==2:
    print("This is a Prime Number")
else:
    print("its not a Prime Number")
