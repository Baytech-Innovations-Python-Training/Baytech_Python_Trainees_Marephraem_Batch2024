#finding even and odd numbers
l=int(input("Enter the limit :"))
even=[]
odd=[]
for i in range (l):
   n=int(input("enter the Number:"))
   if n%2==0:
        even.append(n)

   else:
        odd.append(n)    
print ("Number of Even Numbers:",len(even))
print ("Number of Odd Numbers:",len(odd))
