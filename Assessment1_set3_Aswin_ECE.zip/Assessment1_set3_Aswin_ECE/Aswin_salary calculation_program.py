gender=input("Enter the gender")
qualification=input("Enter the qualification")
experience=int(input("Enter the year of service"))
if gender=="M" and experience>=10 and qualification=="PG":
    print("Salary:15000")
if gender=="M" and experience>=10 and qualification=="G":
     print("Salary:10000")
elif gender=="M" and experience<10 and qualification=="PG":
    print("Salary:10000")
elif gender=="M" and experience<10 and qualification=="G":
     print("Salary:7000")
elif gender=="FM" and experience>=10 and qualification=="PG":
    print("Salary:12000")
if gender=="FM" and experience>=10 and qualification=="G":
     print("Salary:9000")
elif gender=="FM" and experience<10 and qualification=="PG":
    print("Salary:10000")
elif gender=="FM" and experience<10 and qualification=="G":
     print("Salary:6000")
