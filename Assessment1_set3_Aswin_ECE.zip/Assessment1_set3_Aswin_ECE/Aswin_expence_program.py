quantity_purchased=int(input("enter the quality"))
amount_per_item=int(input("enter the quantity"))
if quantity_purchased>1000:
    total=amount_per_item*quantity_purchased
    total_expence=total-10/100
    print("total expence",total_expence)
elif quantity_purchased>10:
    total=amount_per_item*quantity_purchased
    total_expence=total-10/100
    print("total expence",total_expence)
else:
    total_expence=amount_per_item*quantity_purchased
    print("total expence",total_expence)
