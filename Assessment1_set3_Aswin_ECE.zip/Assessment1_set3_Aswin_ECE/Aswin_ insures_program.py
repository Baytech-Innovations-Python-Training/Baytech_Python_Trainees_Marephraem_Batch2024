age=int(input("Enter  the age"))
gender=input("Enter the gender")
status=input("Enter the marital status")
if status=="m":
  print("Driver is insured")
elif status=="um" and age>30:
     print("Driver is insured")
elif status=="um" and age>25 and gender=="fm":
    print("Driver is insured")
else:
    print("Driver is insured")
