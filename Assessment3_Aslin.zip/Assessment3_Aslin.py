1.#gross salary
def calculate_gross_salary(basic_salary):
    if basic_salary < 1500:
        hra = 0.10 * basic_salary
        da = 0.90 * basic_salary
    else:
        hra = 500
        da = 0.98 * basic_salary
    
    gross_salary = basic_salary + hra + da
    return gross_salary

# Taking input from the user
basic_salary = float(input("Enter the basic salary: "))
gross_salary = calculate_gross_salary(basic_salary)
print(f"Gross Salary: Rs. {gross_salary:.2f}")

2.#find factor
def find_factors(number):
    factors = []
    for i in range(1, number + 1):
        if number % i == 0:
            factors.append(i)
    return factors

# Taking input from the user
number = int(input("Enter a number: "))
factors = find_factors(number)

print(f"The factors of {number} are: {factors}")

3.#Reverse of n digit number
def reverse_number(number):
    reversed_num = 0
    while number > 0:
        digit = number % 10
        reversed_num = reversed_num * 10 + digit
        number //= 10
    return reversed_num

# Taking input from the user
n = int(input("Enter an n-digit number: "))
reversed_n = reverse_number(n)

print(f"The reverse of {n} is: {reversed_n}")

4.#fibonacci series
def fibonacci_series(n):
    fib_series = [0, 1]
    while fib_series[-1] + fib_series[-2] <= n:
        next_fib = fib_series[-1] + fib_series[-2]
        fib_series.append(next_fib)
    return fib_series

# Taking input from the user
limit = int(input("Enter the upper limit: "))
fibonacci_numbers = fibonacci_series(limit)

print("Fibonacci Series:")
for num in fibonacci_numbers:
    print(num, end=" ")

5.#largest number from a list
def find_largest_number(numbers):
    if not numbers:
        return None
    
    largest = numbers[0]
    for num in numbers:
        if num > largest:
            largest = num
    return largest

# Taking input from the user
num_list = [int(x) for x in input("Enter a list of numbers separated by spaces: ").split()]
largest_number = find_largest_number(num_list)

if largest_number is not None:
    print(f"The largest number in the list is: {largest_number}")
else:
    print("The list is empty.")

6.#remove duplicates from a list
def remove_duplicates(input_list):
    unique_list = []
    for item in input_list:
        if item not in unique_list:
            unique_list.append(item)
    return unique_list

# Taking input from the user
input_list = [int(x) for x in input("Enter a list of numbers separated by spaces: ").split()]
result_list = remove_duplicates(input_list)

print("List with duplicates removed:")
for item in result_list:
    print(item, end=" ")

7.#clone or copy
def clone_list(original_list):
    copied_list = original_list.copy()  # Using the built-in copy method
    return copied_list

# Taking input from the user
original_list = [int(x) for x in input("Enter a list of numbers separated by spaces: ").split()]
copied_list = clone_list(original_list)

print("Original List:", original_list)
print("Copied List:", copied_list)

8.#add space between potential words
def add_spaces(input_string):
    potential_words = []
    word = ""

    for char in input_string:
        if char.isalpha():
            word += char
        else:
            if word:
                potential_words.append(word)
                word = ""
    
    if word:  # Handling the last word
        potential_words.append(word)
    
    spaced_string = " ".join(potential_words)
    return spaced_string

# Taking input from the user
input_string = input("Enter the string with potential words: ")
result_string = add_spaces(input_string)

print("String with spaces between potential words:")
print(result_string)

9.#get the 4th element
def main():
    my_tuple = (10, 20, 30, 40, 50, 60, 70, 80, 90, 100)
    
    fourth_element = my_tuple[3]
    fourth_from_last = my_tuple[-4]
    
    print("Original Tuple:", my_tuple)
    print("4th Element:", fourth_element)
    print("4th Element from the end:", fourth_from_last)

if __name__ == "__main__":
    main()

10.#elements exist within a tuple
def check_element_in_tuple(my_tuple, element):
    if element in my_tuple:
        return True
    else:
        return False

# Taking input from the user
my_tuple = tuple(input("Enter elements of the tuple separated by spaces: ").split())
element_to_check = input("Enter the element to check: ")

result = check_element_in_tuple(my_tuple, element_to_check)

if result:
    print(f"The element '{element_to_check}' exists in the tuple.")
else:
    print(f"The element '{element_to_check}' does not exist in the tuple.")

11.#to convert a tuple to a dictionary
def tuple_to_dictionary(input_tuple):
    dictionary = {}
    for item in input_tuple:
        key, value = item
        dictionary[key] = value
    return dictionary

# Taking input from the user
tuple_list = [tuple(input("Enter a key-value pair separated by a space: ").split()) for _ in range(3)]
converted_dict = tuple_to_dictionary(tuple_list)

print("Converted Dictionary:", converted_dict)

12.#Sort a tuple of tuples by 2nd item
def sort_tuple_of_tuples(input_tuple):
    sorted_tuple = sorted(input_tuple, key=lambda x: x[1])
    return sorted_tuple

# Example tuple of tuples
tuple_of_tuples = ((1, 5), (2, 2), (3, 8), (4, 3), (5, 1))

sorted_tuples = sort_tuple_of_tuples(tuple_of_tuples)
print("Sorted Tuple of Tuples by 2nd item:")
for item in sorted_tuples:
    print(item)

13.#to Convert Tuple to Set
def tuple_to_set(input_tuple):
    converted_set = set(input_tuple)
    return converted_set

# Taking input from the user
input_tuple = tuple(input("Enter elements of the tuple separated by spaces: ").split())
converted_set = tuple_to_set(input_tuple)

print("Converted Set:", converted_set)

14.#Check if a set is a subset, using comparison operators
def check_subset(super_set, sub_set):
    if sub_set <= super_set:  # sub_set is a subset of super_set
        return True
    else:
        return False

# Taking input from the user
super_set = set(input("Enter elements of the super set separated by spaces: ").split())
sub_set = set(input("Enter elements of the sub set separated by spaces: ").split())

is_subset = check_subset(super_set, sub_set)

if is_subset:
    print("The second set is a subset of the first set.")
else:
    print("The second set is not a subset of the first set.")

15.#.program to count number of vowels using sets in given string
def count_vowels(input_string):
    vowels = set("AEIOUaeiou")  # Creating a set of vowels
    vowel_count = 0

    for char in input_string:
        if char in vowels:
            vowel_count += 1

    return vowel_count

# Taking input from the user
input_string = input("Enter a string: ")
vowel_count = count_vowels(input_string)

print(f"Number of vowels in the string: {vowel_count}")

16.#to check whether a given key already exists in a dictionary
def check_key_in_dict(input_dict, key):
    if key in input_dict:
        return True
    else:
        return False

# Taking input from the user
input_dict = {"name": "John", "age": 30, "city": "New York"}
key_to_check = input("Enter the key to check: ")

key_exists = check_key_in_dict(input_dict, key_to_check)

if key_exists:
    print(f"The key '{key_to_check}' exists in the dictionary.")
else:
    print(f"The key '{key_to_check}' does not exist in the dictionary.")

17.#Write a program to sum all the values of a dictionary
def sum_dictionary_values(input_dict):
    total_sum = sum(input_dict.values())
    return total_sum

# Taking input from the user
input_dict = {
    "a": 10,
    "b": 20,
    "c": 30,
    "d": 40
}

total_sum = sum_dictionary_values(input_dict)

print(f"The sum of all values in the dictionary is: {total_sum}")






