age=int(input('enter the age'))
sex=input('enter the gender')
maritial_status=input('enter the maritial status')
if maritial_status =='m' or 'M':
    print('driver should be insured')
elif maritial_status=='U' or 'u' and sex=='M' or 'm' and age>=30:
    print('driver should be insured')
elif maritial_status=='U' or 'u' and sex=='F' or 'f' and age>=25:
    print('driver should be insured')
else:
    print('driver should not be insured')
