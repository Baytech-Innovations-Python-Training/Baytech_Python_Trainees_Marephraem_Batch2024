gender=input('Enter the gender m/f')
level_of_education=int(input('enter the qualification(post_graduate(1),graduate(0))'))
year_of_service=int(input('enter the year of service'))

if gender=='m':
   if level_of_education==1 and year_of_service>=10:
       salary=15000
       print('salary=',salary)
   elif level_of_education==1 and year_of_service<=10:
       
        salary=10000
        print('salary=',salary)
        
           
   elif level_of_education==0 and year_of_service>=10:
            salary=10000
            print('salary=',salary)

   elif level_of_education==0 and year_of_service<=10:
            salary=7000
            print('salary=',salary)
      
if gender=='f':
   if level_of_education==1 and year_of_service>=10:
       salary=12000
       print('salary=',salary)
   elif level_of_education==1 and year_of_service<=10:
       
        salary=10000
        print('salary=',salary)
        
           
   elif level_of_education==0 and year_of_service>=10:
            salary=9000
            print('salary=',salary)

   elif level_of_education==0 and year_of_service<=10:
            salary=6000
            print('salary=',salary)         
      

              




           





