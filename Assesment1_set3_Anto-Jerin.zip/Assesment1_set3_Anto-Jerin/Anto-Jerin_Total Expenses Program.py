qty=int(input('enter the quality purshased'))
amt=int(input('enter the amount per item'))
if qty>1000:
    total_expense=(qty*amt)*(10/100)
    print(total_expense)
elif qty>10:
    total=(qty*amt)*(10/100)
    total_expense=(qty*amt)-total
    print(total_expense)
else:
    total_expense=(qty*amt)
    print(total_expense)
    
