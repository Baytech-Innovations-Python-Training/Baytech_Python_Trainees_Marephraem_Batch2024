               #7.FINDING EXPONENT OF THE NUMBER 

#fing base num and power from user
base = int(input("Enter the base number: "))
power = int(input("Enter the power number: "))
res = 1

while power > 0:
    res *= base
    power -= 1

print("Result:", res)
