               #6.FIND THE STRONGEST NUMBER

#prompting the number from user
num = int(input("Enter a number: "))
a = num
sum_of_factorials = 0

#check condition
while num > 0:
    rem = num % 10
    fact = 1

    for i in range(1, rem + 1):
        fact *= i
    sum_of_factorials += fact
    num //= 10

#strong number or not
if sum_of_factorials == a:
    print("Strong number")
else:
    print("Not a strong number")
