                        #3.TO FIND THE ARMSTRONG NUMBER


# prompting number from user
num = int(input("Enter a number: "))

# assigning orginal_num as the prompt num
original_num = num
sum = 0

# sum of cubes of digits
while num > 0:
    digit = num % 10
    sum += digit ** 3
    num //= 10

# Check the condition
if sum == original_num:
    print(original_num, "is an Armstrong Number.")
else:
    print(original_num, "is not an Armstrong Number.")
