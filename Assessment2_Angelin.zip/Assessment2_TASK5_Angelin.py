                        # 5.REVERSE OF THE NUMBER


 
#prompting the number from user
num = int(input("Enter the Number: "))
original_num = num
reverse_num = 0

while num != 0:
    rem = num % 10
    reverse_num = reverse_num * 10 + rem
    num = num // 10

print("Before Number:", original_num)
print("Reverse Number:", reverse_num)
