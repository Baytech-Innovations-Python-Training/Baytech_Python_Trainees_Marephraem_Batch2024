                   #4.FIND COUNT OF EVEN AND ODD NUMBER

#prompt the limit
limit = int(input("Enter the limit: "))
even = []
odd = []

for n in range(1, limit + 1):
    value = int(input("Enter the Value: "))
    if value % 2 == 0:
        even.append(n)
    else:
        odd.append(n)

print("Even numbers:", even)
print("Number of even :", len(even))
print("Odd numbers:", odd)
print("Number of odd :", len(odd))
