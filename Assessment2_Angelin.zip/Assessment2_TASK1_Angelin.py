                                      #ASSESMENT 2
#task 1

                        #1.TO FIND THE FACTOR OF THE  NUMBER

#prompting a number from user
x=int(input("enter the number"))
for i in range(1,x+1): 
    if x%i==0:   #divisor condition
        print(i)


                       


          


        


            



               


     






                
              





    










        

 
