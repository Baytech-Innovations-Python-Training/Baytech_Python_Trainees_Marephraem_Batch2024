                                        #2.TO FIND PRIME OR NOT
      

#prompting a number from user
number=int(input("enter the number"))
sums=0

#range from 2 to prompt limit
for i in range(2,number):
    if(number%i==0):
        sums+=1

#checks the condition        
if sums==0:
    print(" This is a prime number")
else:
    print("This is not a prime number")
