def count_vowels(input_string):
    vowels = {'a', 'e', 'i', 'o', 'u'}
    vowel_count = 0
    for char in input_string:
        if char in vowels:
            vowel_count += 1
    return vowel_count

if __name__ == '__main__':
    try:
        input_string = input("Enter a string: ").lower()
        num_vowels = count_vowels(input_string)
        print("Number of vowels:", num_vowels)
    except ValueError:
        print("Invalid input. Please enter a valid string.")
