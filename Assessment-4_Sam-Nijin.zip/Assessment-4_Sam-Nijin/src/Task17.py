def sum_dictionary_values(dictionary):
    total_sum = sum(dictionary.values())
    return total_sum

if __name__ == '__main__':
    try:
        sample_dict = {'a': 10, 'b': 20, 'c': 30}
        total = sum_dictionary_values(sample_dict)
        print(f"Sum of dictionary values: {total}")
    except ValueError:
        print("Invalid input. Please enter valid elements.")
