def check_element_exists(element, tuple_data):
    return element in tuple_data

if __name__ == '__main__':
    try:
        tuple_data = tuple(input('Enter elements separated by spaces: ').split())
        element_to_check = input('Enter the element to check: ')
        exists = check_element_exists(element_to_check, tuple_data)
        if exists:
            print(f'The element "{element_to_check}" exists in the tuple.')
        else:
            print(f'The element "{element_to_check}" does not exist in the tuple.')
    except ValueError:
        print('Invalid input. Please enter valid elements.')
