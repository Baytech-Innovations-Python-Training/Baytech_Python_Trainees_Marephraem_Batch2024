class NumberReverser:
    def __init__(self, number):
        self.number = number
        self.reversed_num = self.reverse_number()

    def reverse_number(self):
        reversed_num = 0
        temp_number = self.number
        while temp_number > 0:
            digit = temp_number % 10
            reversed_num = reversed_num * 10 + digit
            temp_number //= 10
        return reversed_num

    def display_reversed_number(self):
        print(f'Reverse of {self.number} is: {self.reversed_num}')

if __name__ == '__main__':
    try:
        n = int(input('Enter a number: '))
        if n < 0:
            print('Please enter a non-negative integer.')
        else:
            number_reverser = NumberReverser(n)
            number_reverser.display_reversed_number()
    except ValueError:
        print('Invalid input. Please enter a valid integer.')
