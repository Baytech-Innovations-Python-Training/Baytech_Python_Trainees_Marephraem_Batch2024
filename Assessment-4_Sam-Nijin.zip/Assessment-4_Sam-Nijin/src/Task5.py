class LargestNumberFinder:
    def __init__(self, num_list):
        self.num_list = num_list
        self.largest_number = self.find_largest_number()

    def find_largest_number(self):
        if not self.num_list:
            return None
        largest = self.num_list[0]
        for num in self.num_list:
            if num > largest:
                largest = num
        return largest

    def display_largest_number(self):
        if self.largest_number is None:
            print("The list is empty.")
        else:
            print(f"The largest number is: {self.largest_number}")

if __name__ == '__main__':
    try:
        num_list = [int(x) for x in input("Enter numbers separated by spaces: ").split()]
        largest_number_finder = LargestNumberFinder(num_list)
        largest_number_finder.display_largest_number()
    except ValueError:
        print("Invalid input. Please enter valid integers.")
