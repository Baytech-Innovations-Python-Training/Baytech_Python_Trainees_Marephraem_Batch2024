class FibonacciGenerator:
    def __init__(self, limit):
        self.limit = limit
        self.fibonacci_series = self.generate_fibonacci_series()

    def generate_fibonacci_series(self):
        fibonacci_series = [0, 1]
        while fibonacci_series[-1] + fibonacci_series[-2] <= self.limit:
            next_fibonacci = fibonacci_series[-1] + fibonacci_series[-2]
            fibonacci_series.append(next_fibonacci)
        return fibonacci_series

    def display_fibonacci_series(self):
        print(f'Fibonacci Series: {self.fibonacci_series}')

if __name__ == '__main__':
    try:
        limit = int(input('Enter the limit: '))
        if limit <= 0:
            print('Please enter a positive limit.')
        else:
            fibonacci_generator = FibonacciGenerator(limit)
            fibonacci_generator.display_fibonacci_series()
    except ValueError:
        print('Invalid input. Please enter a valid integer.')
