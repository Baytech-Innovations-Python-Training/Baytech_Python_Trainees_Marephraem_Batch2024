def sort_tuple_by_second_item(tuple_data):
    sorted_tuple = sorted(tuple_data, key=lambda x: x[1])
    return sorted_tuple

if __name__ == '__main__':
    try:
        tuple_data = [(1, 'apple'), (3, 'cherry'), (2, 'banana')]
        sorted_tuple = sort_tuple_by_second_item(tuple_data)
        print("Sorted tuple:", sorted_tuple)
    except ValueError:
        print("Invalid input. Please enter valid elements.")
