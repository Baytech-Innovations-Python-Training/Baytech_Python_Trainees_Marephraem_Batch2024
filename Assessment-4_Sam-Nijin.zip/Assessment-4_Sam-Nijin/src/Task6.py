def remove_duplicates(input_list):
    unique_list = []
    for item in input_list:
        if item not in unique_list:
            unique_list.append(item)
    return unique_list

if __name__ == '__main__':
    try:
        input_list = [int(x) for x in input("Enter elements separated by spaces: ").split()]
        unique_elements = remove_duplicates(input_list)
        print("List with duplicates removed:", unique_elements)
    except ValueError:
        print("Invalid input. Please enter valid elements.")
