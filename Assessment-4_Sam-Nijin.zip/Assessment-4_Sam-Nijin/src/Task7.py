def clone_list(input_list):
    return input_list.copy()

if __name__ == '__main__':
    try:
        input_list = [int(x) for x in input("Enter elements separated by spaces: ").split()]
        cloned_list = clone_list(input_list)
        print("Cloned list:", cloned_list)
    except ValueError:
        print("Invalid input. Please enter valid elements.")
