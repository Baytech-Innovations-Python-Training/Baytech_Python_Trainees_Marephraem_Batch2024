def get_elements(tuple_data):
    if len(tuple_data) >= 4:
        fourth_element = tuple_data[3]
        fourth_from_last = tuple_data[-4]
        return fourth_element, fourth_from_last
    else:
        return None, None

if __name__ == '__main__':
    try:
        tuple_data = tuple(input('Enter elements separated by spaces: ').split())
        fourth, fourth_from_last = get_elements(tuple_data)
        if fourth is not None and fourth_from_last is not None:
            print(f'4th element: {fourth}')
            print(f'4th element from last: {fourth_from_last}')
        else:
            print('The tuple doesn\'t have enough elements.')
    except ValueError:
        print('Invalid input. Please enter valid elements.')
