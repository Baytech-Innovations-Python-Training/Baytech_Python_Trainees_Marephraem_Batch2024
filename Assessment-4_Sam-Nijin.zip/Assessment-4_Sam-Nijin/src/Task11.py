def tuple_to_dict(tuple_data):
    dictionary = {}
    for key, value in tuple_data:
        dictionary[key] = value
    return dictionary

if __name__ == '__main__':
    try:
        tuple_data = [(1, 'apple'), (2, 'banana'), (3, 'cherry')]
        converted_dict = tuple_to_dict(tuple_data)
        print("Converted dictionary:", converted_dict)
    except ValueError:
        print("Invalid input. Please enter valid elements.")
