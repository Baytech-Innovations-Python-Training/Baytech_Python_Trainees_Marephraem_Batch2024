class CalculateGross:
    def __init__(self, base_salary):
        self.base_salary = base_salary
        hra = self.calc_hra(base_salary=base_salary)
        da = self.calc_da(base_salary=base_salary)
        self.gross_salary = base_salary + hra + da

    def calc_hra(self, base_salary):
        if base_salary < 1500:
            return base_salary * (10 / 100)
        else:
            return 500

    def calc_da(self, base_salary):
        if base_salary < 1500:
            return base_salary * (90 / 100)
        else:
            return base_salary * (98 / 100)

if __name__ == '__main__':
    base_salary = float(input('Enter base salary: '))
    gross_salary = CalculateGross(base_salary)
    print(f'Gross Salary: {gross_salary.gross_salary}')
