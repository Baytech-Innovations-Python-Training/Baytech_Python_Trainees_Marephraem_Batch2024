def check_key_exists(dictionary, key):
    return key in dictionary


if __name__ == '__main__':
    try:
        dict = {'a': 1, 'b': 2, 'c': 3}
        key = input("Enter a key to check: ")
        exists = check_key_exists(dict, key)

        if exists:
            print(f"The key '{key}' exists in the dictionary.")
        else:
            print(f"The key '{key}' does not exist in the dictionary.")
    except ValueError:
        print("Invalid input. Please enter valid elements.")
