def check_subset(set1, set2):
    return set1 <= set2


if __name__ == '__main__':
    try:
        set1 = {1, 2}
        set2 = {1, 2, 3, 4, 5}
        is_subset = check_subset(set1, set2)

        if is_subset:
            print("set1 is a subset of set2.")
        else:
            print("set1 is not a subset of set2.")
    except ValueError:
        print("Invalid input. Please enter valid elements.")
