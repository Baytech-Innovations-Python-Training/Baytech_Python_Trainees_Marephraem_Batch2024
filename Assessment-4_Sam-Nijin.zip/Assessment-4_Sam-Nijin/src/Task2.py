class FactorFinder:
    def __init__(self, number):
        self.number = number
        self.factors = self.find_factors()

    def find_factors(self):
        factors = []
        for i in range(1, self.number + 1):
            if self.number % i == 0:
                factors.append(i)
        return factors

    def display_factors(self):
        print(f'Factors of {self.number} are: {self.factors}')

if __name__ == '__main__':
    try:
        number = int(input('Enter a number: '))
        if number <= 0:
            print('Enter a positive integer only')
        else:
            factor_finder = FactorFinder(number)
            factor_finder.display_factors()
    except ValueError:
        print("Invalid input. Please enter a valid integer.")
