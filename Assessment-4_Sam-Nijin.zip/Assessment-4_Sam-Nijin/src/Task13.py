def tuple_to_set(tuple_data):
    converted_set = set(tuple_data)
    return converted_set

if __name__ == '__main__':
    try:
        tuple_data = (1, 2, 3, 4, 5)
        converted_set = tuple_to_set(tuple_data)
        print("Converted set:", converted_set)
    except ValueError:
        print("Invalid input. Please enter valid elements.")
