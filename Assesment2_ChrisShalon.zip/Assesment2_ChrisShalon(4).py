4.#To write a program to count and print the number of odd and even numbers
l=int(input("Enter the limit"))
even=[]
odd=[]
for i in range(l):
    n=int(input("Enter the values:"))
    if(n%2==0):
        even.append(n)
    else:
        odd.append(n)
print("Number of even:",len(even))
print("Number of odd:",len(odd))
