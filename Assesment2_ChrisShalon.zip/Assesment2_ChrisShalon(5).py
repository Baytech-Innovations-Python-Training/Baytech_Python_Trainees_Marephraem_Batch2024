#To write a program to find the reverse of n digit number using while loop
num=int(input("Enter the number:"))
print("Before Number:",num)
sum=0
while(num>0):
    rem=num%10
    sum=sum*10+rem
    num=num//10
print("Reverse Number:",sum)
