#To find whether the given number is prime or not
x=int(input("Enter a number:"))
sum=0
for i in range(1,x+1):
    if(x%i==0):
        sum=sum+1
if(sum==2):        
        print("This is a prime number")
else:
    print("This is not a prime number") 
