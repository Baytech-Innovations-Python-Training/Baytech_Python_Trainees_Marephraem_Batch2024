#To write a program to find the given number is Armstrong number or not
x=int(input("Enter the Number:"))
temp=x
sum=0
while(x>0):
    d=x%10
    sum+=d**3
    x=x//10
if(temp==sum):
    print(temp,"is an Armstrong number")
else:
     print(temp,"is not an Armstrong number")
