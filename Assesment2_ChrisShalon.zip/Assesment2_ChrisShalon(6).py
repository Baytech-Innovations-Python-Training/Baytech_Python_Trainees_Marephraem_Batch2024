#To find the reverse of n digit number using while loop
num=int(input("Enter the number:"))
a=num
sum=0
while(num>0):
    rem=num%10
    fact=1
    for i in range(1,rem+1):
        fact=fact*i
    sum+=fact
    num=num//10
if(sum==a):
    print(a,"is a strong number")
else:
    print(a,"is not a strong number")
