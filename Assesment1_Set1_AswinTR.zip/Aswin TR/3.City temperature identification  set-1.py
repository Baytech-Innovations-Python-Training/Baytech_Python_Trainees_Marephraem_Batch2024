#City temperature identification
#getting the input temperature in fahrenheit using float
fr=float(input("Enter the Temperature :"))
#fahrenheit is converted into centigrade usung mathamatical formula 
cent=(fr-32)*5/9
#printing the output 
print ("Temperature in Centigrade =",cent)
