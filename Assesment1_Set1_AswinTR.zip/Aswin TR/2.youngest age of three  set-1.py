#youngest age of three python program
#getting the input of age 
age1=int(input("Enter the age of Ram :"))
age2=int(input("Enter the age of Shyam :"))
age3=int(input("Enter the age of Ajay :"))
#coparing the ages and printing the result
if age1 < age2 and age1 < age3:
       print ("The Youngest Age is Ram")
elif age2 < age1 and age2 < age3:
       print ("The Youngest Age is Shyam")
else:
    print ("The Youngest Age is Ajay")
