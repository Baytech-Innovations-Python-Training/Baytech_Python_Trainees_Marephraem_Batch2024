#Profit Loss Programming in Python
#the cost price and selling price is got as input 
cost_price=float(input("Enter the Cost Price of an Item :"))
selling_price=float(input("Enter the Selling Price of an Item :"))
#if the selling price is greater cot price then the profit is printed 
if selling_price > cost_price:
    print ("Profit :",selling_price - cost_price)
#if the selling price is less cot price then the loss is printed 
elif selling_price < cost_price:
        print ("Loss :",cost_price - selling_price)
#if the selling price and cot price is equal then No profit No loss is printed
else:
        print ("No Profit No Loss")
