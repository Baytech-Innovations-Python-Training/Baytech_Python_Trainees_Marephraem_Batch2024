#program to find whether the given number is prime or not
Num=int(input("Enter the Number :"))
def Prime():
    Sum=0
    for i in range(1,Num+1):
        if Num%i==0:
            Sum+=1
    if Sum==2:
        print(Num,"is a Prime Number!!")
    else:
        print(Num,"is not a Prime Number!!")
Prime()


