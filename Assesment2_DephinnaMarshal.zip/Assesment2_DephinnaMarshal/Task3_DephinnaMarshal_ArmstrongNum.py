#program to find the given number is Armstrong number or not
num = int(input("Enter a Number: ")) #prompting the input from user
Sum=0
temp= num  #temporary variable for storing original value of inputed number.
while temp > 0 :
    new = temp %10
    Sum +=new**3   #calculating sum by adding cube 
    temp //= 10     #removing last digit from temporary variable and repeating
if (Sum == num):    #checking if calculated sum equals with entered number, then it's
        print ("The Given Number",num,"is an armstrong number")
else:
        print ("The Given Number",num,"is Not An Armstrong Number.")
