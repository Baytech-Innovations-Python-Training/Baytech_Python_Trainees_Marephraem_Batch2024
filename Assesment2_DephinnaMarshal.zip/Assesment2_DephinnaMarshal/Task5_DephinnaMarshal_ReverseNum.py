#program to find the reverse of n digit number using While loop
Num=int(input("Enter the Number :"))
print("Before Number :",Num)
Sum=0
while Num>0 :
    Rem=Num%10
    Sum=(Sum*10)+Rem
    Num=Num//10
print("Reversed Number :",Sum)
