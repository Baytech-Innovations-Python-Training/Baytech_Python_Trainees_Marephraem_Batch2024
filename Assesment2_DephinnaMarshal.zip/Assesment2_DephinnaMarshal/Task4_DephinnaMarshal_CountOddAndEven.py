#program to count and print the number of odd and even numbers
Evens=0
Odds=0
limit=int(input("Enter the limit :"))
for i in range(limit):
    num = int(input("Enter the Values :")) #prompts user's input for each iteration
    if num%2==0:#checks if the number is even,if it is
        Evens+=1  #Even is incremented
    else:         #if not
        Odds+=1   #odd is incremented
print("Number of Evens :",Evens)
print("Number of Odds :",Odds)


    