Base=int(input("Enter the Base :"))
Power=int(input("Enter the Power :"))
res=1
while Power>0:
    res*=Base
    Power-=1
print("Answer :",res)