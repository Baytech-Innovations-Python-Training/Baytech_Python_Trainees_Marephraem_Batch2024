#program to find the given number is strong number
Num=int(input("Enter the Num :"))
a=Num
Sum=0
while Num>0:
    Rem=Num%10
    fact=1
    for i in range(1,Rem+1):
        fact*=i
    Sum+=fact
    Num//=10
if Sum==a:
    print(a,"is a strong number!!")
else:
    print(a,"is not a Strong Number!")
