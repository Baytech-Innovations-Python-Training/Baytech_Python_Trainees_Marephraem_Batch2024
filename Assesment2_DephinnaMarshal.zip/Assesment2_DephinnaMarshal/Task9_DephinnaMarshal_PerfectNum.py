Num=int(input("Enter the Number :"))
for i in range(1,Num):
    if(Num%i==0):
        print(i)