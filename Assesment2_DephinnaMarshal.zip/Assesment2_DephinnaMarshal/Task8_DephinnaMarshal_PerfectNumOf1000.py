#program to print the perfect number between 1-1000
#This program is finding the divisors of the number 1000
Num=1000
for i in range(1,Num):
    if(Num%i==0):
        print(i)