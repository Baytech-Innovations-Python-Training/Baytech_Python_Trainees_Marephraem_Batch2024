"""Program to find whether a number is Armstrong number or not"""
num=int(input("Enter a number to find is it an Armstrong number:"))
sum=0
temp=num
i=0
while(num>i):
    rem=num%10
    cube=rem**3
    sum=sum+cube
    num//=10
if(sum==temp):
    print(temp,"is an Armstrong number")
else:
    print(temp,"is not an Armstrong number")







