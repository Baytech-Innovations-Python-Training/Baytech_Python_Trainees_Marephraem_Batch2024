"""Program to find the prompted number is prime or not"""
x=int(input("Enter a number to find it a prime:"))
for i in range(2,x+1):
    if(x%i!=0):
        print(x,"is a prime number")
        break
    else:
        print(x,"is not a prime number")
        break