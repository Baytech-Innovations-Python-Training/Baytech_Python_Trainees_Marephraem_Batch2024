"""Program to find number of Odd and Even numbers"""
l=int(input("Enter the limit:"))
a=[]
e=[]
o=[]
for i in range(0,l):
    num=int(input("Enter the value:"))
    a.append(num)
for j in range(len(a)):
    if(a[j]%2==0):
        e.append(a[j])
    elif(a[j]%2!=0):
        o.append(a[j])

print("Number of Even:",len(e))
print("Number of Odd:",len(o))


