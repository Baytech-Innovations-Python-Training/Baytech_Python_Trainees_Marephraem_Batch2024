"""Program to find the given number is a Strong number"""
num=int(input("Enter the number to find is it a Strong number:"))
a=num
sum=0
while(0<num):
    rem=num%10
    fact=1
    for i in range(1,rem+1):
        fact*=i
    sum+=fact
    num//=10
if(sum==a):
    print(a,"is a Strong number")
else:
    print(a,"is not a Strong number")
