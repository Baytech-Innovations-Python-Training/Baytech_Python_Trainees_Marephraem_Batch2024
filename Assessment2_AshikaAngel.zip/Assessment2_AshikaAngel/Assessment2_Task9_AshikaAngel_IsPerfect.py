"""Program to find the given number is a perfect number"""
num=int(input("Enter a number:"))
for i in range(1,num):
    if(num%i==0):
        print(i)