"""Program to find factor of prompted number"""
x=int(input("Enter a number to find its factor:"))
print("The factor of",x,"is,")
for i in range(1,x+1):
    if(x%i==0):
        print(i)
    