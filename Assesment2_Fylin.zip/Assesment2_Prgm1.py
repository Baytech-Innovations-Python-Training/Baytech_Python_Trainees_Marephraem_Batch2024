# Factor of the given number

x=int(input("Enter the number : ")) #promting the integer input from user
print(f"The factors of {x} are:")
for i in range(1,x+1):
    if x%i==0: #checking the remainder is 0 or not
        print(i) #only if the remainder is 0,it prints i