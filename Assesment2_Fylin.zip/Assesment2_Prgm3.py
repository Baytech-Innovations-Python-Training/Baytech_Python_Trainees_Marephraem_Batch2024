#Program to find Armstrong number or not

n=int(input("Enter the number : "))
num=n
sum=0
while 0<num:
    rem=(num%10)**3
    sum=sum+rem
    num=num//10

if sum==n:
    print(n,"is an armstrong number")
else:
    print(n,"is not an armstrong number")