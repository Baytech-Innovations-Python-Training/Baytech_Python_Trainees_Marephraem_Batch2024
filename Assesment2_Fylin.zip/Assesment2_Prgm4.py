# counting odd and even numbers

l=int(input("Enter the limit : "))
even_num=[]
odd_num=[]
for i in range(l):
    n=int(input("Enter the number:"))
    if n%2==0:
        even_num.append(n)
    else:
        odd_num.append(n)
print("Number of Even:",len(even_num))
print("Number of Odd:",len(odd_num))