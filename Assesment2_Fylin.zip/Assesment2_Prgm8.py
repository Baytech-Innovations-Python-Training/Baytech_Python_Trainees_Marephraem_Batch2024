#The perfect number between 1-1000

for i in range(1,1000):
    if 1000 % i ==0:
        print(i)