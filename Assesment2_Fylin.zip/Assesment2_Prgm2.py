# Program to find a number is prime or not
sum=0
x=int(input("Enter the number : "))
for i in range(1,x+1):
    if x%i==0:
        sum+=1
if sum==2:
    print(x,"is a prime number")
else:
    print(x,"is not a prime number")