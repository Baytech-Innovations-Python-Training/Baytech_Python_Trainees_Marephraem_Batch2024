#Reversing the n digit number

num=int(input("Enter the number:"))
sum=0
number=num

while 0<number:
    rem=number%10
    sum=(sum*10)+rem
    number=number//10

print("Before Number ",num)
print("After Number ",sum)