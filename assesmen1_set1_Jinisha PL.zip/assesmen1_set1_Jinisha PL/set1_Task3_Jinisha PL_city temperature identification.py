#Calculating city temperature
fr=float(input("Enter the temperature: "))
cent=(5/9)*(fr-32)
print("The temperature in centigrade: ",cent)
