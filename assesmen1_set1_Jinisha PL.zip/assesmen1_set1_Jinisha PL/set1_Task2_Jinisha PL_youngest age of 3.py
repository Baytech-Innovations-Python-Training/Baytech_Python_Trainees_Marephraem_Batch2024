#youngest age of three person
ram_age=int(input("Enter age of Ram: "))
shyam_age=int(input("Enter age of Shyam: "))
ajay_age=int(input("Enter age of Ajay: "))
if(ram_age<shyam_age and ram_age<ajay_age):
    print("The Youngest age is Ram")
elif(shyam_age<ram_age and shyam_age<ajay_age):
    print("The Youngest age is Shyam")
else:
    print("The Youngest age is Ajay")