# Python program to Check if a set is a subset, using comparison operators

# Define two sets
set1 = {1, 2, 3, 4}
set2 = {2, 3}

# Check if set2 is a subset of set1
is_subset = set2 <= set1  # Alternatively, you can use set2.issubset(set1)

# Check the result
if is_subset:
    print("set2 is a subset of set1.")
else:
    print("set2 is not a subset of set1.")
