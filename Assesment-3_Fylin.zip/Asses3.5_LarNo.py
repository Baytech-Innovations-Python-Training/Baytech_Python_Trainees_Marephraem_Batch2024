#print largest no. from the list

# Prompt the user to enter a list of numbers separated by spaces
user_input = input("Enter a list of numbers separated by spaces: ")
user_numbers = [int(x) for x in user_input.split()]

# Check if the list is empty
if not user_numbers:
    print("The list is empty.")
else:
    # Find the largest number
    largest_number = max(user_numbers)
    print(f"The largest number in the list is: {largest_number}")
