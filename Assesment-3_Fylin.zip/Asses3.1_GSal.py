# Finding Gross Salary

bs=int(input("Enter the Basic salary : "))
if bs<1500:
    hra=10/100*bs
    da=90/100*bs
    print("The gross salary is : ",bs+hra+da)
else:
    hra=500
    da=98/100*bs
    print("The gross salary is : ",bs+hra+da)

