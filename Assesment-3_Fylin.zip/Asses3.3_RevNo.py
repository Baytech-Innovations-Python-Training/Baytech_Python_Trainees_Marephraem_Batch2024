# Reverse the n digit number using While loop

x=int(input("Enter any number : "))
y=[]
while x>0:
    rem=x%10
    x=int(x/10)
    y.append(rem)
    print(rem)
    print(x)
print("The reverse order of given number is : ",y)
