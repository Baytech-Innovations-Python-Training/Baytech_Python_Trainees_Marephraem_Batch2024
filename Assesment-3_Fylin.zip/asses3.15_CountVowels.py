# Count no. of vowels

# Function to count vowels in a string using sets
def count_vowels(input_string):
    # Define a set of vowels
    vowels = {'a', 'e', 'i', 'o', 'u', 'A', 'E', 'I', 'O', 'U'}

    # Initialize a counter
    vowel_count = 0

    # Iterate through the characters in the string
    for char in input_string:
        # Check if the character is in the set of vowels
        if char in vowels:
            vowel_count += 1

    return vowel_count

# Example usage:
input_string = input("Enter string : ")
result = count_vowels(input_string)
print(f"The number of vowels in the string is: {result}")
