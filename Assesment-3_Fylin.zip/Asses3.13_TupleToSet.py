# Python program to Convert Tuple to Set

# Sample tuple
my_tuple = (1, 2, 2, 3, 4, 4, 5)

# Convert the tuple to a set
my_set = set(my_tuple)

# Print the resulting set
print("Converted set:", my_set)
