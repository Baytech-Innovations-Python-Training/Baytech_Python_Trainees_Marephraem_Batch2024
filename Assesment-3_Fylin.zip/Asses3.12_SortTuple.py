# Sort a tuple of tuples by 2nd item

# Sample tuple of tuples
my_tuple = ((1, 3), (2, 1), (3, 2), (4, 5), (5, 4))

# Sort the tuple of tuples by the second item of each inner tuple
sorted_tuple = sorted(my_tuple, key=lambda x: x[1])

# Print the sorted tuple
print("Sorted tuple:", sorted_tuple)
