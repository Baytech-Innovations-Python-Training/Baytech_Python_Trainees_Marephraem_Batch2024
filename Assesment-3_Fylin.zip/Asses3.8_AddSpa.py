# Add space b/w potential words

def add_spaces_between_words(input_string):
    result_string = ""

    for char in input_string:
        # If the character is an uppercase letter, add a space before it
        if char.isupper() and result_string:
            result_string += " "
        result_string += char

    return result_string

# Example usage:
input_string = "HelloWorldThisIsAnExample"
formatted_string = add_spaces_between_words(input_string)
print(formatted_string)
