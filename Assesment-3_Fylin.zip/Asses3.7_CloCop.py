# Clone or copy the list

original_list = [1, 2, 3, 4, 5]

# Clone the list using the list() constructor
copied_list = list(original_list)

# Print the original and copied lists
print("Original list:", original_list)
print("Copied list:", copied_list)
