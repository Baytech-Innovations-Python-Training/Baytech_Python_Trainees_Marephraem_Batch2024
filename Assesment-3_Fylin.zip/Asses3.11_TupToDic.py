# Tuple to Dictionary

# Sample tuple of key-value pairs
my_tuple = (("a", 1), ("b", 2), ("c", 3))

# Convert the tuple to a dictionary
my_dict = dict(my_tuple)

# Print the resulting dictionary
print("Converted dictionary:", my_dict)
