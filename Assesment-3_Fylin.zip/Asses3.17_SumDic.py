# Sum all the values in the dictionary
# Sample dictionary
my_dict = {'a': 10, 'b': 20, 'c': 30, 'd': 40}

# Initialize a variable to store the sum
total_sum = 0

# Iterate through the values and add them to the sum
for value in my_dict.values():
    total_sum += value

# Print the total sum
print("The sum of all values in the dictionary is:", total_sum)
