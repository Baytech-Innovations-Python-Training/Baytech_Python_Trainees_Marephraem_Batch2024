# Remove duplicates from the list

# Input list with duplicates
input_list = [1, 2, 2, 3, 4, 4, 5]

# Remove duplicates using a set
unique_list = list(set(input_list))
# We convert input_list to a set using set(), which automatically removes duplicates since sets cannot contain duplicate elements.

# Print the list with duplicates removed
print("List with duplicates removed:", unique_list)
