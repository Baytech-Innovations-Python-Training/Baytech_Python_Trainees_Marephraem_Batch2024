# IS element exist in the list

# Sample tuple
my_tuple = (1, 2, 3, 4, 5)

# Element to check for existence
element_to_check = 3

# Check if the element exists in the tuple
if element_to_check in my_tuple:
    print(f"{element_to_check} exists in the tuple.")
else:
    print(f"{element_to_check} does not exist in the tuple.")
