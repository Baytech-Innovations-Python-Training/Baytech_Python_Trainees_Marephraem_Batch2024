


        #  1.If his basic salary is less than Rs. 1500, then HRA = 10% of basic salary and DA = 90% of basic salary.
        #If his salary is either equal to or above Rs. 1500, then HRA = Rs. 500 and DA = 98% of basic salary.
        #If the employee's salary is input through the keyboard write a program to find his gross salary.
basic_salary = float(input("Enter the basic salary: "))
if basic_salary <= 1500:
    hra = 0.1 * basic_salary
    da = 0.9 * basic_salary
elif basic_salary==0 or  basic_salary>1500:
    hra = 500
    da = 0.98 * basic_salary
gross_salary = basic_salary + hra + da
print(f"Gross Salary: Rs. {gross_salary:.2f}")



         #   2.Write a program to find the factor of the given number.
number=int(input("Enter the number:"))
print("Factors of",number,"are:")
for i in range(1,number +1):
    if number % i==0:
        print(i)


        #  3.Write a program to find the reverse of n digit number using While loop
num = int(input("Enter a number: "))
reverse = 0
while num > 0:
    digit = num % 10 #remainder value
    reverse = reverse * 10 + digit
    num = num // 10 #quotient value
print(f"The reverse of the number is: {reverse}")




             #   4.Write a program to find the Fibonacci Series of the given number.
#The first two terms are 0 and 1. All other terms are obtained by adding the preceding two terms. 
limit = int(input("Enter the limit for the Fibonacci series: "))
a, b = 0, 1
print("Fibonacci Series:")
print(a, end=" ")

while b <= limit:
    print(b, end=" ")
    a, b = b, a + b




            #   5.Write a Python program to get the largest number from a list
# Input a list of numbers
num_list = [int(x) for x in input("Enter a list of numbers separated by spaces: ").split()]
# Initialize the largest variable with the first number in the list
largest = num_list[0]
# Iterate through the list to find the largest number
for num in num_list:
    if num > largest:
        largest = num
print(f"The largest number in the list is: {largest}")



"""
"""
                #   6.Write a Python program to remove duplicates from a list
# Predefined list of elements
input_list = [1, 2, 2, 3, 4, 4, 5, 6, 6, 7]
# Initialize an empty list to store unique elements
unique_list = []
# Iterate through the input list and add elements to unique_list if they are not already present
for element in input_list:
    if element not in unique_list:
        unique_list.append(element)
print("List after removing duplicates:", unique_list)





                 #   7.Write a Python program to clone or copy a list
# Original list
original_list = [1, 2, 3, 4, 5]
# Create an empty list to store the cloned elements
cloned_list = []
# Iterate through the original list and add elements to the cloned list
for element in original_list:
    cloned_list.append(element)
print("Original List:", original_list)
print("Cloned List:", cloned_list)





              #    8.Write a Python Program to Add Space between Potential Words
# Potential words usually consist of multiple capitalized words joined together
# Input a string without spaces
input_string = input("Enter a string without spaces: ")
# Initialize an empty string to store the modified string with spaces
modified_string = ""
# Iterate through the characters in the input string
for char in input_string:
# Add a space before each uppercase letter (except the first character)
    if char.isupper() and modified_string:
        modified_string += " "
    modified_string += char
print("Modified String:", modified_string)



               #    9.Write a Python program to get the 4th element and 4th element from last of a tuple
# Create a tuple
my_tuple = (1, 2, 3, 4, 5, 6, 7, 8, 9, 10)
# Get the 4th element
fourth_element = my_tuple[3]
# Get the 4th element from the end
fourth_from_end = my_tuple[-4]
print("4th Element:", fourth_element)
print("4th Element from End:", fourth_from_end)




              #    10.Write a Python program to check whether an element exists within a tuple
# Create a tuple
my_tuple = (1, 2, 3, 4, 5, 6, 7, 8, 9, 10)
# Element to check
element_to_check = int(input("Enter an element to check: "))
# Check if the element exists in the tuple
if element_to_check in my_tuple:
    print(f"{element_to_check} exists in the tuple.")
else:
    print(f"{element_to_check} does not exist in the tuple.")






                #    11.Write a Python program to convert a tuple to a dictionary
# Example tuple
example_tuple = (("a", 1), ("b", 2), ("c", 3))
# Convert tuple to dictionary
result_dict = dict(example_tuple)
print("Original Tuple:", example_tuple)
print("Converted Dictionary:", result_dict)





              #   12.Sort a tuple of tuples by 2nd item
# Example tuple of tuples
tuple_of_tuples = (("apple", 3), ("banana", 1), ("orange", 2), ("grape", 4))
# Sort the tuple of tuples by the second item of each inner tuple
sorted_tuples = sorted(tuple_of_tuples, key=lambda x: x[1])
print("Original Tuple of Tuples:", tuple_of_tuples)
print("Sorted Tuple of Tuples by 2nd Item:", sorted_tuples)





                #   13.Write a Python program to Convert Tuple to Set

# Example tuple
example_tuple = (1, 2, 3, 3, 4, 4, 5)
# Convert tuple to set
result_set = set(example_tuple)
print("Original Tuple:", example_tuple)
print("Converted Set:", result_set)







             #   14.Write a Python program to Check if a set is a subset, using comparison operators
# Define two sets
set1 = {1, 2, 3}
set2 = {1, 2, 3, 4, 5}
# Check if set1 is a subset of set2 using comparison operators
is_subset = set1 <= set2  # Alternatively, you can use set1.issubset(set2)
# Print the result
if is_subset:
    print("set1 is a subset of set2")
else:
    print("set1 is not a subset of set2")







           #    15.program to count number of vowels using sets in given string
# Get input string from the user
input_string = input("Enter a string: ")
# Initialize a set of vowels
vowels = {'a', 'e', 'i', 'o', 'u', 'A', 'E', 'I', 'O', 'U'}
# Count the number of vowels
vowel_count = 0
for char in input_string:
    if char in vowels:
        vowel_count += 1

print("Number of vowels:", vowel_count)






           #   16.Write a Python program to check whether a given key already exists in a dictionary
# Example dictionary
example_dict = {"name": "John", "age": 30, "city": "New York"}
# Get the key from the user
key_to_check = input("Enter a key to check: ")
# Check if the key exists in the dictionary
if key_to_check in example_dict:
    print(f"The key '{key_to_check}' exists in the dictionary.")
else:
    print(f"The key '{key_to_check}' does not exist in the dictionary.")





      #    17.Write a program to sum all the values of a dictionary
# Example dictionary
example_dict = {"a": 10, "b": 20, "c": 30, "d": 40}
# Calculate the sum of all values in the dictionary
total_sum = sum(example_dict.values())
print("Dictionary:", example_dict)
print("Sum of all values:", total_sum)


      






















