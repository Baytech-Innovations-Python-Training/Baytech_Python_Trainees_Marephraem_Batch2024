#profit loss program
cost_price=float(input("Enter the cost price of an item:"))
selling_price=float(input("Enter the selling price of an item:"))
if selling_price>cost_price:
    profit=selling_price-cost_price
    print("Profit:",profit)
elif cost_price>selling_price:
    loss=cost_price-selling_price
    print("Loss:",loss)
else:
    print("No Profit No Loss")


#youngest age of three program
age1=int(input("Enter the age of Ram:"))
age2=int(input("Enter the age of Shyam:"))
age3=int(input("Enter the age of Ajay:"))
if age1<age2 and age1<age3:
    print("The Youngest Age is Ram")
elif age2<age1 and age2<age3:
    print("The Youngest Age is Shyam")
else:
    print("The Youngest Age is Ajay")

#city temperature identification
fr=float(input("Enter the Temperature:"))
#Celsius=(5/9)*(Fahrenheit-32)
cent=5/9*(fr-32)
print("Temperature in Centigrade=",cent)
    

    
