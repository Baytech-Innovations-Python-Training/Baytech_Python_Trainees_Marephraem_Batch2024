#(11)  profit loss program in python
CostPrice=cp=int(input("Enter the cost price of an iten:"))
sellingPrice=sp=int(input("Enter the selling price of an iten:"))
if sp>cp:
    profit=(float(sp-cp)) 
    print("profit",profit)
if cp>sp:
    lost=(float(sp-cp)) 
    print("lost",lost)
if cp==sp:
    print("result:no profit no loss")


    
#(12) youngest age of three program in python

age1=int(input("Enter the Age of Ram:"))
age2=int(input("Enter the Age of shyam:"))
age3=int(input("Enter the Age of Ajay:"))

if age1<age2 and age1<age3:
    print("The Youngest Age is Ram")
    
elif age2<age1 and age2<age3:
        print("The Youngest Age is shyam")

elif age3<age1 and age3<age2:
        print("The Youngest Age is Ajay")

elif age1==age2:
      print("The Youngest Age is Ram and shyam")

elif age1==age3:
    print("The Youngest Age is Ram and Ajay")
    
elif age2==age1:
    print("The Youngest Age is shyam and Ram")
elif age2==age3:
    print("The Youngest Age is shyam and Ajay")
elif age3==age1:
    print("The Youngest Age is Ajay and Ram")
elif age3==age2:
    print("The Youngest Age is Ajay and shyam")

#(13) city temperature identification

f=float(input("Enter the Temperature:"))
centigrade=float((f-32)*5/9)
print("temperature in centigrade",centigrade)



    

















    
    
       

    
    






    
