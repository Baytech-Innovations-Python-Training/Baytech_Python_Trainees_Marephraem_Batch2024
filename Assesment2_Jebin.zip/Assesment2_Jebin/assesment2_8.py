num = 1000
for i in range(1, num):
       if num % i == 0:
    print(i)