x= int(input("Enter a number: "))
sum=0
for i in range(1, x + 1):
       if x % i == 0:
           sum=sum+1
if(sum==2):
	print("This is a Prime Number")
else:
	print("This is a Not Prime Number")
