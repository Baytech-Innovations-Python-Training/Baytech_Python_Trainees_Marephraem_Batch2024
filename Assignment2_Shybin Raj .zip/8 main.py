#8.write a program to print the perfect number between 1-1000

num=int(input("Enter the number:"))
for i in range(1,num):
    if num%i==0:
        print(i)