#5.write a program to find the reverse of n digit number using while loop

num=int(input("Enter the Number:"))
temp=num
sum=0
while num>0:
    rem=num%10
    sum=(sum*10)+rem
    num=num//10
print("Before Number:",temp)
print("Reversed Number:",sum)