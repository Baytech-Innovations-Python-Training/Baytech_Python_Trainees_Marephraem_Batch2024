#2.write a program to find whether the given number is prime or not

x=int(input("Enter the number:"))
sum=0
for i in range(1,x+1):
    if x % i==0:
        sum+=1
if sum==2:
    print("This is a Prime Number")
else:
    print("it's not a Prime Number")