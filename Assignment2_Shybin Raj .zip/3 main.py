#3.write a program to find the given number is armstrong number or not

num=int(input("Enter the Number:"))
a=num
sum=0
while a>0:
    rem = a%10
    sum += rem**3
    a//=10
if num == sum:
    print(num,"is a Armstrong Number")
else:
    print(num,"is a Not Armstrong Number")
