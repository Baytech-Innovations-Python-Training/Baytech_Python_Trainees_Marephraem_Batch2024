#Calculating  a Total Expenses
QuantityPurchased=int(input("Enter the QuantityPurchased:"))
Amount=int(input("Enter the Amount per Item:"))
Total_Expenses= QuantityPurchased*Amount
if QuantityPurchased>1000:
    print("The Total_Expenses is ",QuantityPurchased*10/100)
elif QuantityPurchased>10:
        print("True,The Total_Expenses is ",QuantityPurchased*Amount-10/100)
else:
        print("False,The Total_Expenses is",QuantityPurchased*Amount)