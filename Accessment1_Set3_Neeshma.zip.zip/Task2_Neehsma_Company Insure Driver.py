#Company Insure Driver Program in python
Age=int(input("Enter the Age:"))
Gender=(input("Enter the Gender(Male,Female):"))
MaritalStatus=(input("Enter the Status(Married,Unmarried):"))
if MaritalStatus=="Married":
    print("Driver should be Insured")
if MaritalStatus=="Unmarried" and Gender=="Male" and Age>30:
    print("Driver should be Insured")
elif MaritalStatus=="Unmarried" and Gender=="Female" and Age>25:
    print("Driver should be Insured")
else:
    print("Driver should not be Insured")