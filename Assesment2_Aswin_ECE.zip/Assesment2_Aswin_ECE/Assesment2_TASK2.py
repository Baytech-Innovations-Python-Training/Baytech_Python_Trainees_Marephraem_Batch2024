#find whether the given number is prime or not
sum=1
num=int(input("Enter the number:"))
for i in range (1,num):
    if num%i==0:
        sum+=1
if sum==2:
    print(num,"is a prime number")
else:
    print(num,"is not a prime number")
