#find the reverse of n digit number using While loop
num=int(input("Enter the number:"))
sum=0
number=num
while number>0:
    rem=number%10
    sum=(sum*10)+rem
    number=number//10
print("Before Number ",num)
print("After Number ",sum)
