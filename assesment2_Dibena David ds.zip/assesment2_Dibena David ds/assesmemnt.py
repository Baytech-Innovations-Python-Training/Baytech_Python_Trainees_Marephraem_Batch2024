"""#(1) find the factor of the given program
x=int(input("ENTER THE VALUE:"))
for i in range(1,x+1):
    if x%i==0:
        print(i)
        
#(2) find the prime number
num=int(input("ENTER THE  NUMBER:"))
sum=0
for i in range(1,num+1):
    if num%i==0:
        sum+=1
if sum==2:
    print(num," is a prime number")
else:
    print(num," is not a prime number")
#(3)Armstrong number

num = int(input("Enter a number: ")) 
sum = 0 
temp = num 
while temp > 0: 
    digit = temp % 10 
    sum += digit ** 3 
    temp //= 10 
if num == sum: 
    print(num,"is an Armstrong number") 
else: 
    print(num,"is not an Armstrong number") 
#(4)
limit= int(input("Enter the limit: ")) 
even=0 
odd=0 
for i in range(limit):
    value=int(input("enter the value:"))
    if value % 2 == 0: 
        even+=1 
    else: 
        odd+=1 
print("Number of even numbers:", even) 
print("Number of odd numbers:", odd)

#(5)
num = int(input("Enter a number: "))
print("before number:", num)
rev = 0 
while num > 0: 
    rem = num % 10 
    rev = (rev * 10) + rem 
    num = num // 10  
print("Reversed number:", rev)

#(6)
num = int(input("Enter a number: ")) 
a = num 
sum = 0 
while num > 0: 
    rem = num % 10 
    fact = 1 
    for i in range(1, rem+1): 
        fact = fact * i 
    sum = sum + fact 
    num = num // 10 
if sum == a: 
    print("The number is a strong number.") 
else: 
    print("The number is not a strong number.") 
#(7)
base = int(input("Enter the base number: "))
pow = int(input("Enter the power number: "))
res = 1
while pow > 0:
    res *= base
    pow -= 1
print("The result is:", res)

#(8)
for i in range(1, 1000):
    if 1000 % i == 0:
        print(i)"""
#(9)
num = int(input("Enter a number: "))
for i in range(1, num):
    if num % i == 0:
        print(i)

















































































