fr=float(input("Enter the temperature in fahrenheit:"))
cent=(5/9)*(fr-32)
print("Temperature in fahrenheit:",fr)
print("Temperature i centigrade:",cent)
