age1=int(input("enter the age of ram"))
age2=int(input("enter the age of shyam"))
age3=int(input("enter the age of ajay"))
if(age1<age2 and age1<age3):
    print("youngest age is ram")
elif(age2<age3 and age2<age3):
    print("youngest age is shyam")
else:
    print("youngest age is ajay")


