a=float(input("cost_price:"))
b=float(input("selling_price:"))
profit=(b-a)
loss=(a-b)
if(b>a):
    print("profit:",profit)
elif(a>b):
    print("loss:",loss)
else:print("no profit no loss")




