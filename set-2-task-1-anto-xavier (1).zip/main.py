sellingprice=float(input("enter the selling price")) 
profit=float(input("enter the profit"))
costprice=sellingprice-profit
cost_price_per_item = costprice//15
print("costprice per item",cost_price_per_item)