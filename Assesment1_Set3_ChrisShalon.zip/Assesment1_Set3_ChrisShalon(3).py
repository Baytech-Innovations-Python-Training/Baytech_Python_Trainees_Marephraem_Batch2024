#Calculate Salary program in python
"""Get the gender (f/m),years of service and qualification (Graduate(0),Post_Graduate(1)) as the input from the userby prompting"""
Gender=input("Enter the Gender f/m:")
Years_of_service=int(input("Enter the Years of service:"))
Qualification=int(input("Enter the Qualification (Graduate(0),Post_Graduate(1)):"))
"""Using the if statement find the gender, years of service, qualification and salary assigned according to the condition"""
if(Gender=="m" and Years_of_service>=10 and Qualification==1):
    salary=15000
    print("Salary Assigned",salary)
elif(Gender=="m" and Years_of_service>=10 and Qualification==0):
    salary=10000
    print("Salary Assigned",salary)
elif(Gender=="m" and Years_of_service<10 and Qualification==1):
    salary=10000
    print("Salary Assigned",salary)
elif(Gender=="m" and Years_of_service<10 and Qualification==0):
    salary=7000
    print("Salary Assigned",salary)
elif(Gender=="f" and Years_of_service>=10 and Qualification==1):
    salary=12000
    print("Salary Assigned",salary)
elif(Gender=="f" and Years_of_service>=10 and Qualification==0):
    salary=9000
    print("Salary Assigned",salary)
elif(Gender=="f" and Years_of_service<10 and Qualification==1):
    salary=10000
    print("Salary Assigned",salary)
elif(Gender=="f" and Years_of_service<10 and Qualification==0):
    salary=6000
    print("Salary Assigned",salary)       
else:
    print("Invalid")
