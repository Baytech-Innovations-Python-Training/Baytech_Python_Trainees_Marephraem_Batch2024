#Company insures drivers program in python
"""Get the Age,Gender (M/F-Male/Female) and Martial status (U/M-Unmarried/Married) of a driver from the user by prompting """
Age=int(input("Enter the Age:"))
Gender=input("Enter the Gender M/F:")
Martial_status=input("Enter the Martial Status U/M:")
"""using if-elif-else statement check the driver's martial status,gender,age and apply the given conditions to be insured"""
if(Martial_status=="M"):
    print("Driver should be Insured")
elif(Martial_status=="U" and Gender=="M" and Age>30):
    print("Driver should be Insured")
elif(Martial_status=="U" and Gender=="F" and Age>25):
    print("Driver should be Insured")
else:
    print("Driver should not be Insured")
