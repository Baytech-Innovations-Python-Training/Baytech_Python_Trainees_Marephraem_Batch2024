#Total Expenses Program in Python
""" Get quantity and amount purchased from the user by proming""" 
qty=int(input("Enter the Quantity Purchased:"))
amt=int(input("Enter the Amount per item:"))
total_expenses=qty*amt#total expenses is the product of quantity and amount purchased
"""if the quantity is greater than 10 ,then the final expenses is given by subtracting 10% from total expenses else print total expenses"""
if(qty>10):
    final_total_expenses=total_expenses-total_expenses*10/100
    print("Total expenses is:",final_total_expenses)
else:
    print("Total expenses is:",total_expenses)
    
