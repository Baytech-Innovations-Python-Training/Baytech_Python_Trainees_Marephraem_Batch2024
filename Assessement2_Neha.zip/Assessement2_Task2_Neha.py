#prime or not
number=int(input("Enter the number:"))
sum=0
for i in range(2,number):
        if (number%i==0):
                sum+=1
if sum==0:
        print("This is a prime number")
else:
     print(" This is Not a prime number")
