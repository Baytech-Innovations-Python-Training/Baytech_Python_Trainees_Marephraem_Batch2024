#9.FIND THE PERFECT NUMBERS
num=int(input("enter a number:"))
for i in range(1,num):
    if(num%i==0):
        print(i)

            
