#armstrong number
num=int(input("Enter the number:"))
orginal_num=num
sum=0
while num>0:
        digit=num%10
        sum+=digit**3
        num//=10
if sum==orginal_num:
        print(orginal_num,"is a armstrong number")
else:
        print(original_num, "is not a Armstrong Number.")
