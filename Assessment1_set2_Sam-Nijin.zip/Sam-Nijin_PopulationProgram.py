# Given Data
total_population = 80000
total_men = total_population * 52 // 100
total_literacy = total_population * 48 // 100
literate_men = total_population * 35 // 100

# Calculated data
total_women = total_population - total_men
literate_women = total_literacy - literate_men
total_illeterate_men = total_men - literate_men
total_illeterate_women = total_women - literate_women

# Displaying the result
print(f'Total Population : {total_population}')
print(f'Total Mens : {total_men}')
print(f'Total Womens : {total_women}')
print(f'Total Literacy : {total_literacy}')
print(f'Total Literacy Men : {literate_men}')
print(f'Total Literacy Women : {literate_women}')
print(f'Total Not Literacy Men : {total_illeterate_men}')
print(f'Total Not Literacy Women : {total_illeterate_women}')