# Prompting the required data
sp = float(input('Enter the selling price : '))
profit = float(input('Enter the profit : '))


# Aggregating
cp = sp - profit

cp = cp // 15

# Displaying the results
print(f'cost of per item is {cp}')