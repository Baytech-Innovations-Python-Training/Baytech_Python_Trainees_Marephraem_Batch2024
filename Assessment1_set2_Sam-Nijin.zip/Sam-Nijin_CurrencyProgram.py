# Prompting the cash
amt = int(input('Enter amount to be withdraw : '))

# Aggregating
hundred = amt // 100
amt = amt % 100
fifty = amt // 50
amt = amt % 50
ten = amt// 10

# Displaying the results
print(f'no of Hundred Notes : {hundred}')
print(f'no of Fifty Notes : {fifty}')
print(f'no of Ten Notes : {ten}')