#1
total=80000
men=52/100*total
women=42/100*total
literacy=48/100*total
literacymen=35/100*literacy
literacywomen=13/100*literacy
nonliteracymen=total-literacymen
nonliteracywomen=total-literacywomen
print("The Total Pouplation:",total)
print("Total mens:",men)
print("Total Womens:",women)
print("Total Literacy Mens:",literacymen)
print("Total Literacy Womens:",literacywomen)
print("Total Literacy:",literacy)
print("Total Not Literacy Mens:",nonliteracymen)
print("Total Not Literacy Women:",nonliteracywomen)
#2
amount=int(input("Enter the Amount to be Withdraw:"))
a=amount/100

print("No of Hundred Notes:",a)
b=amount%100
c=b/50
print("No Of Fifty Notes:",c)
e=amount%50
d=e/10
print("No Of Ten Notes:",d)
#3
sp=int(input("Enter the Selling Price:"))
profit=int(input("Enter the Profit:"))
cp=sp-profit
a=cp/15
print("Cost Price of Per Item:",a)




