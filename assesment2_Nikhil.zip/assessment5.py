#Finding the strong number
def strong():
    num=int(input("Enter the range:"))
    a=num
    sum=0
    while num>0:
        rem=num%10
        fact=1
        for x in range(1,rem+1):
            fact=fact*x
        fact=sum+fact
        num=num//10
    if sum==a:
        print("strong number")
    else:
        print("Not a strong number")
        
strong()
def display():  
    for x in range(0,100):
        a=int(input("Enter 1 to start"))
        if a==1:
            strong()
        else:
            print("Exiting....")
            break
    
display()
