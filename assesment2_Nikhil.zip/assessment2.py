#Finding the prime number
def prime():
    x=int(input("Enter a Number:"))  
    if x>1:
        for i in range (2,x):
            if (x%i==0):
                print("It is not a prime number")
                break       
            else:
                print("It is a prime number")
                break
            
prime()
def display():  
    for x in range(0,100):
        a=int(input("Enter 1 to start"))
        if a==1:
            prime()
        else:
            print("Exiting....")
            break
    
display()
