#Finding the perfect number
def perfect():
    base=int(input('Enter the base value:'))
    pow=int(input('Enter the power value:'))
    res=base**pow
    print("Result:",res)
perfect()
def display():  
    for x in range(0,100):
        a=int(input("Enter 1 to start"))
        if a==1:
            perfect()
        else:
            print("Exiting....")
            break
    
display()
