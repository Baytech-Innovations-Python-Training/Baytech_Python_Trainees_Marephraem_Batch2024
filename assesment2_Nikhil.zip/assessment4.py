#Finding the odd or even number
def oddeven():
    array=[]
    even=0
    odd=0
    j=int(input('Enter the limit of array elements:'))
    for x in range(1,j):
        array.append(int(input("Enter array elements:")))
    print("Array elements:",array)    
    i = int(input("Enter the limit: "))    
    for y in range(1,i):  
        if (array[y]%2==0):
            odd+=1
        else:
            even+=1
    print("odd number:",odd)
    print("even number:",even)
oddeven()
def display():  
    for x in range(0,100):
        a=int(input("Enter 1 to start"))
        if a==1:
            oddeven()
        else:
            print("Exiting....")
            break
    
display()
