#Finding the armstrong number
def armstrong():
    num = int(input("Enter a number: "))
    sum = 0
    temp = num
    while temp > 0:
        digit = temp % 10
        sum += digit ** 3
        temp //= 10

    if num == sum:
        print(num,"is an Armstrong number")
    else:
        print(num,"is not an Armstrong number")
            
armstrong()
def display():  
    for x in range(0,100):
        a=int(input("Enter 1 to start"))
        if a==1:
            armstrong()
        else:
            print("Exiting....")
            break
    
display()
