#Finding the factor
def factor():
    x=int(input("Enter a value:"))
    
    for i in range (1,x+1):
        if x%i==0 :
           print(i,"is the factor of",x)

factor()
def display():  
    for x in range(0,100):
        a=int(input("Enter 1 to start"))
        if a==1:
            factor()
        else:
            print("Exiting....")
            break
    
display()
