#Finding the perfect number
def perfect():
    num=int(input("Enter the range:"))
    for x in range(1,num):  
        if (num%x==0):
            print("Perfect numbers in",num,":",x)
perfect()
def display():  
    for x in range(0,100):
        a=int(input("Enter 1 to start"))
        if a==1:
            perfect()
        else:
            print("Exiting....")
            break
    
display()
