#Finding the perfect numbers
def perfect():
    i=int(input("Enter the range:"))
    for x in range(1,i):  
        if (i%x==0):
            print(x,end=" ")
perfect()
def display():  
    for x in range(0,100):
        a=int(input("Enter 1 to start"))
        if a==1:
            perfect()
        else:
            print("Exiting....")
            break
    
display()
