#calculating the Prime Number
num=int(input("Enter the number:"))
sum=0
for i in range(1,num+1):
    if (num % i) == 0:
        sum=sum+1
if(sum==2):
    print(" This is a prime number  ")
else:
    print(" This is not a prime number  ")