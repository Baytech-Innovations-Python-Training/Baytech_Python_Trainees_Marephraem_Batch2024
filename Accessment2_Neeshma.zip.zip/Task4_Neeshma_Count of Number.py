#Finding the count of Odd and Even Number
array=[]
even_num,odd_num=0,0
limit=int(input("Enter the limit:"))
for i in range(limit):
  num = int(input(f"Enter the values(i+1):"))
array.append(num)
for num in range(limit):
 if num%2==0:
  even_num+=1
 else:
  odd_num+=1
print("The Count of Even Number:",even_num)
print("The Count of odd number:",odd_num)