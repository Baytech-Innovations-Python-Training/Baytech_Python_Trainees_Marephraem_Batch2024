#Check the number is Strong Number
num=int(input("Enter the Number:"))
a=num
sum=0
while(a>0):
    i = 1
    rem=a%10
    fact=1
    while(i<rem+1):
        fact=fact*i
        i=i+1
    sum=sum+fact
    a=a//10
if (sum==num):
  print(num,"is a strong number")
else:
 print(num, "is  not a strong number")

