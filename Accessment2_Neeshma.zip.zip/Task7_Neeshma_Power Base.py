#Calculating the power raised to another
sum=0
base=int(input("Enter the base number:"))
pow=int(input("Enter the power number:"))
res=1
while pow!=0:
    res*=base
    pow-=1
print("The power raised is:",res)

