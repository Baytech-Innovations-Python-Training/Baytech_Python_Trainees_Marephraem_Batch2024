#Calculating the perfect Number between 1 to  1000
i=1
n=int(input("Enter the limit:"))
for i in range(1,n):
 if 1000 % i==0:
  print(i)