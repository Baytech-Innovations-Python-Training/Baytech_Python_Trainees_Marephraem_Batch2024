#Reverse the n-digit number using while loop
num=int(input("Enter the number:"))
sum=0
temp=num
while temp>0:
    rem=temp%10
    sum=(sum*10) +rem
    temp=temp//10
print('Before number:', num)
print('Reverse number:',sum)