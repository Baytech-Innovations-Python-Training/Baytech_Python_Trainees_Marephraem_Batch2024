#Calculating the Amstrong Number
num=int(input("Enter the number:"))
sum=0
temp=num
while(temp>0):
 digit=temp%10
 sum+=digit*digit*digit
 temp=temp//10
 if sum==num:
     print(num,"is a  Amstrong  Number")
 else:
     print(num, "is  not a  Amstrong  Number")

