#Calculating the factor of given number
def factors(x):
 print("Enter the number:",x)
 i=1
 for i in range(1,x+1 ):
  if x % i==0:
   print(i)
x=10
factors(x)
