#Finding a perfect Number
num=int(input("Enter the number:"))
i=1
for i in range(1,num):
  if  num%i==0:
      print(i)