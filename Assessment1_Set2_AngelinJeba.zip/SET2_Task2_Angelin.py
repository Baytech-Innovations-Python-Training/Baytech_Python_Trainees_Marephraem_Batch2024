                                          #QUESTION SET 2
                                             #TASK 2


"""            2. Currency Program in Python

A cashier has currency notes of denominations 10, 50 and 100.
If the amount to be withdrawn is input through the keyboard in hundreds,
find the total number of currency notes of each denomination the
cashier will have to give to the withdrawer.
This program is written in the Python programming language and
it is designed to accept an input from the user representing an amount to be withdrawn.
Then, it calculates the number of hundred-rupee notes, fifty-rupee notes and ten-rupee notes required to withdraw the entered amount.
It starts by using the "input()" function to accept a value from the user which is stored in a variable
named "amt".
The program then uses the "//" operator to divide the "amt" variable by 100, and assigns the quotient
to the variable "hundred".
This calculates the number of hundred-rupee notes required to withdraw the entered amount.
The program then uses the modulus operator "%" to find the remainder of the division of "amt" by 100
and assigns it to the variable "amt".
This is done because the remainder is used to calculate the number of fifty-rupee notes required.
Then the program again uses the "//" operator to divide the updated "amt" variable by 50, and assigns
the quotient to the variable "fifty".
This calculates the number of fifty-rupee notes required to withdraw the entered amount.
Then, the program uses the modulus operator again to find the remainder of the division of "amt" by
50, and assigns it to the variable "amt".
This is done because the remainder is used to calculate the number of ten-rupee notes required.
Then the program again uses the "//" operator to divide the updated "amt" variable by 10, and assigns
the quotient to the variable "ten".
This calculates the number of ten-rupee notes required to withdraw the entered amount.
Finally, the program uses the "print()" function to display the number of hundred-rupee notes, fifty-
rupee notes and ten-rupee notes required to withdraw the entered amount """

#prompting amount from user
amt=int(input("Enter the amount withdraw:"))

#calculates the no.of hundred ruppes need too require
hundred=amt//100

#calculates the remaining amount after withdraw of 100
hundred_remaining=amt%100

#calculates the no. of fifty rupees note to required
fifty=hundred_remaining//50

#calculates the remaining amount after the ithdraw of fifty
fifty_remaining=hundred_remaining%50

#calculates the no.of ten rupees note
ten=fifty_remaining//10


print("No of hundred notes\t:", hundred)
print("No of fifty notes\t:",fifty )
print("No of ten notes\t: ",ten )
