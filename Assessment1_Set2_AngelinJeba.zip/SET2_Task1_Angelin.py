                                      #question set:2
                                         #task 1

"""                 1. Population Program in Python
In a town, the percentage of men is 52. The percentage of total literacy is 48. If total percentage of
literate men is 35 of the total population, write a program to find the total number of illiterate men
and women if the population of the town is 80,000.
This program calculates the population, literacy rate, and gender breakdown of a fictional population
with a total of 80000 people. It first calculates the number of men and women in the population by
assuming that men make up 52% of the population, and women make up the remaining 48%.
Then, it calculates the literacy rate of the population by assuming that 48% of the population is literate.
From there, it calculates the number of literate men and women by assuming that 35% of men and the
corresponding percentage of women are literate. Finally, it calculates the number of non-literate men
and women by subtracting the number of literate men and women from the total number of men and
women, respectively. The program then prints out these values for the population, men, women,
literacy, literate men and women, non-literate men and women."""

#given
PercentageMen=52

TotalLiteracy=48

TotalPopulation=80000

PercentageLiterateMen = 35 

    
#calculate no.of men and women    
NumOfMen=52/100 *  TotalPopulation
NumOfWomen =TotalPopulation-NumOfMen 

#calculate literate men and literate women
LiteracyRatePopulation=(48/100)* TotalPopulation
NumLiterateMen =(35/100) *TotalPopulation
NumLiterateWomen= LiteracyRatePopulation - NumLiterateMen 

#calculate no.of non literate men and literate women
num_non_literate_men=NumOfMen-NumLiterateMen 
num_non_literate_women=NumOfWomen-NumLiterateWomen

#print
print("Total Population: " ,TotalPopulation)
print("Total Mens: " , NumOfMen)
print("Total Womens: " ,NumOfWomen )
print("Total Literacy: " ,LiteracyRatePopulation)
print("Total Literacy  Women :" ,NumLiterateWomen)
print("Total Literacy  Men :" ,NumLiterateMen)
print("Total Not Literacy  Women :" ,num_non_literate_women)
print("Total Not Literacy  Men :" ,num_non_literate_men)
