                                      #question set:2
                                         #task 3

"""3. Cost Price Per Item Program in Python
If the total selling price of 15 items and the total profit earned on them is input through the keyboard,
write a program to find the cost price of one item.
This program is written in the Python programming language and it is designed to calculate the cost
price of an item based on the selling price and profit.
It starts by using the "input()" function to accept two values from the user, the selling price and profit,
which are stored in variables named "sp" and "profit" respectively. The program then uses basic math
subtraction operation to subtract the profit from the selling price and assigns the result to the variable
"cp".
The program then uses the "//" operator to divide the "cp" variable by 15, and assigns the quotient to
the variable "cp". This is done to find the cost price of per item. Finally, the program uses the "print()"
function to display the cost price of per item."""

#prompting sp and profit from the user
sp=int(input("Enter the Selling Price\t:"))
profit=int(input("Enter The Profit:"))

#subtract profit from selling price
cp=sp-profit

#to find cost price of each item
costperitem=cp//15

#display cost per item
print("Cost Price of Per Item :",costperitem)
