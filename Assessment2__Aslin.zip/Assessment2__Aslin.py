 #ASSESSMENT 2

                        #1.TO FIND THE FACTOR OF THE  NUMBER

#prompting a number from user
x=int(input("enter the number"))
for i in range(1,x+1): 
    if x%i==0:   #divisor condition
        print(i)


                         #2.TO FIND PRIME OR NOT
      

#prompting a number from user
number=int(input("enter the number"))
sums=0

#range from 2 to prompt limit
for i in range(2,number):
    if(number%i==0):
        sums+=1

#checks the condition        
if sums==0:
    print(" This is a prime number")
else:
    print("This is not a prime number")


                        #3.TO FIND THE ARMSTRONG NUMBER


# prompting number from user
num = int(input("Enter a number: "))

# assigning orginal_num as the prompt num
original_num = num
sum = 0

# sum of cubes of digits
while num > 0:
    digit = num % 10
    sum += digit ** 3
    num //= 10

# Check the condition
if sum == original_num:
    print(original_num, "is an Armstrong Number.")
else:
    print(original_num, "is not an Armstrong Number.")


                       #4.FIND COUNT OF EVEN AND ODD NUMBER

#prompt the limit
limit = int(input("Enter the limit: "))
even = []
odd = []

for n in range(1, limit + 1):
    value = int(input("Enter the Value: "))
    if value % 2 == 0:
        even.append(n)
    else:
        odd.append(n)

print("Even numbers:", even)
print("Number of even :", len(even))
print("Odd numbers:", odd)
print("Number of odd :", len(odd))
# 5.REVERSE OF THE NUMBER
 

num = int(input("Enter the Number: "))
original_num = num
reverse_num = 0

while num != 0:
    rem = num % 10
    reverse_num = reverse_num * 10 + rem
    num = num // 10

print("Before Number:", original_num)
print("Reverse Number:", reverse_num)



                #6.FIND THE STRONGEST NUMBER


num = int(input("Enter a number: "))
a = num
sum_of_factorials = 0

while num > 0:
    rem = num % 10
    fact = 1

    for i in range(1, rem + 1):
        fact *= i
    sum_of_factorials += fact
    num //= 10

if sum_of_factorials == a:
    print("Strong number")
else:
    print("Not a strong number")
    
 #7.FINDING EXPONENT OF THE NUMBER 

base = int(input("Enter the base number: "))
power = int(input("Enter the power number: "))
res = 1

while power > 0:
    res *= base
    power -= 1

print("Result:", res)

                   #8.DIVISORS OF NUMBER 1000

base = int(input("Enter the base number: "))
power = int(input("Enter the power number: "))
res = 1

while power > 0:
    res *= base
    power -= 1

print("Result:", res)


                  #9.FIND THE PERFECT NUMBERS
                

num=int(input("enter a number"))
for i in range(1,num):
    if(num%i==0):
        print(i)
