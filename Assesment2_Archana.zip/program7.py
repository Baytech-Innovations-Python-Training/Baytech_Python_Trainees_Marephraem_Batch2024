



"""
7.Write a program to find the value of one number raised to the power of another
This program calculates the result of raising a base number to a power. The user is prompted to enter the base number and the power number,
which are then stored in the variables "base" and "pow" respectively. The variable "res" is initialized to 1, as any number raised to the power of 0 is 1.
The program then enters a while loop that continues until the value of "pow" is 0. Inside the while loop, the value of "res" is multiplied by the value of "base"
and "pow" is decremented by 1. This process continues until "pow" is 0, at which point the final value of "res" is the result of raising the base number to the power.
The final result is then printed to the screen.
Expected op:
Enter the Base Number :3
Enter the Power Number :6
Answer : 729"""

base = int(input("Enter the Base Number: "))
pow = int(input("Enter the Power Number: "))
res = 1
while pow > 0:
    res *= base
    pow -= 1
print("Answer:",res)
   

