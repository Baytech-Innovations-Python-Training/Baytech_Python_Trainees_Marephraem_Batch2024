"""
1.Write a program to find the factor of the given number
This program is a simple Python program that takes an input, x, from the user
and then uses a for loop to iterate through the range of numbers from 1 to
x+1. Inside the for loop, an if statement is used to check if the current value of i
is a divisor of x. If it is, the current value of i is printed out. This program finds
and print all divisors of the input number x.
Expected op:
Enter the Number :10
1
2
5
10"""

x=int(input("Enter the Number:"))
for i in range(1,x+1):
    if x%i==0:
        print(i)
