



"""9.Write a program to find the given number is perfect number
This program is a Python script that calculates the divisors of a given number. It starts by prompting the user to enter a number,
which is stored in the variable "num". Then, it uses a for loop to iterate over a range of numbers from 1 to the value of "num" (not including "num" itself).
Inside the for loop, the program uses an if statement to check if the current loop variable (i) is a divisor of the input number by using the modulus operator (%).
If the modulus of "num" and "i" is equal to 0, then "i" is a divisor of "num" and the program prints the value of "i".
The loop continues until all divisors of the input number have been found and printed.
Expected op:
Enter the Number :12
1
2
3
4
6"""

num=int(input("Enter the Number:"))
for i in range(1,num):
    if num%i==0:
        print(i)
