



"""
6.Write a program to find the given number is strong number
This program is a Python program that checks if a given number is a strong number or not. A strong number is a number
whose sum of the factorials of its digits is equal to the number itself.
The program first takes the input of a number from the user and assigns it to the variable 'num'.
Then it creates a variable 'a' and assigns the value of 'num' to it. Next, it creates a variable 'sum' and assigns the value of 0 to it.
The program then enters a while loop that runs as long as the value of 'num' is greater than 0.
Inside the while loop, the program takes the remainder of 'num' divided by 10 and assigns it to the variable 'rem'.
Next, it creates a variable 'fact' and assigns the value of 1 to it.
The program then enters another loop that runs from 1 to the value of 'rem'+1. Inside this loop,
the program multiplies the value of 'fact' by the current value of the loop variable 'i' and assigns it back to 'fact'.
After the inner loop ends, the program adds the value of 'fact' to the variable 'sum' and updates the value of 'num' by dividing it by 10 using floor division.
After the while loop ends, the program checks if the value of 'sum' is equal to the value of 'a'. If it is,
then the program prints that the number is a strong number. Otherwise, it prints that the number is not a strong number.
Expected op:
Enter the Number :26
26 is not a Strong Number"""




num = int(input("Enter the Number: "))
a = num
sum = 0

while num > 0:
    rem = num % 10
    fact = 1
    for i in range(1, rem + 1):
        fact *= i
    sum += fact
    num //= 10

if sum == a:
    print(f"{a} is a Strong Number")
else:
    print(f"{a} is not a Strong Number")
