





"""
8.Write a program to print the perfect number between 1-1000
The above program is finding the divisors of the number 1000. It starts a for loop that iterates from 1 to 1000 (not including 1000).
For each iteration, it checks if the current number in the loop (i) is a divisor of 1000 (if 1000 % i == 0). If it is a divisor, it prints the divisor.
The program will print all the divisors of 1000 which are 1, 2, 4, 5, 8, 10, 20, 25, 40, 50, 100, 125, 200, 250, 500, 1000.
Expected op:
1
2
4
5
8
10
20
25
40
50
100
125
200
250
500"""

for i in range(1,1000):
    if 1000%i==0:
        print(i)
