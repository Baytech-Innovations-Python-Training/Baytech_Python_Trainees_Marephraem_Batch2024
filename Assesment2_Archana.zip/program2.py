

"""
2.Write a program to find whether the given number is prime or not
This program takes an input from the user as a number and then using a for
loop and if-else statement it checks if the number is a prime number or not.
The for loop iterates from 1 to the input number and checks if the input
number is divisible by each number in the range. If it is divisible, the sum
variable is incremented by 1. After the loop ends, the if-else statement checks
if the value of sum is equal to 2. If it is, it prints that the input number is a
prime number, otherwise it prints that it's not a prime number. The program uses the concept of divisibility, looping and conditional statements.
Expected op:
Enter a number: 23
This is a Prime Number"""


num=int(input("Enter a Number:"))
sum_divisors = 0
for i in range(1, num + 1):
    if num % i == 0:
        sum_divisors += 1

if sum_divisors == 2:
     print("This is a prime number.")
else:
    print("This is not a prime number.")
