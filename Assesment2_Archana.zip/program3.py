

"""
3.Write a program to find the given number is Armstrong number or not
This program is used to check whether a given number is an Armstrong number or not. An Armstrong number is a number that is equal to the sum of the cubes of its digits.
The program takes an input from the user, which is the number to be checked. It then initializes a variable "sum" to zero, and uses a while loop to iterate
through each digit of the input number. In each iteration, it takes the remainder of the number when divided by 10, cubes it, and adds it to the "sum" variable.
It then updates the value of the number by dividing it by 10.
After the while loop, it compares the value of "sum" with the original input number. If they are equal, it means the number is an Armstrong number, and
the program prints "is a Armstrong Number". If they are not equal, the number is not an Armstrong number, and the program prints "is a Not Armstrong Number"
The program uses several variables like num, a, sum, rem, and uses the input() function to take input from the user, uses the while loop to iterate through the
digits of the number, uses the modulo operator to find remainder and integer division operator to update the number to check and also uses the if-else statement
to check whether the number is Armstrong or not
Expected op:
Enter the Number :153
153 is a Armstrong Number"""



# Get input from the user
num = int(input("Enter the Number: "))

# Initialize variables
sum = 0
a = num

# Calculate the sum of cubes of digits
while num > 0:
    rem = num % 10
    sum += rem ** 3
    num //= 10

# Check if it is an Armstrong number
if a == sum:
    print(f"{a} is an Armstrong Number.")
else:
    print(f"{a} is Not an Armstrong Number.")





