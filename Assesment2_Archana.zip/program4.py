

"""

4.Write a program to count and print the number of odd and even numbers
This program is used to find the number of even and odd numbers within a certain limit.
The limit is defined by the variable "1" which is taken as input from the user.
The program then uses a for loop to iterate through the range of numbers defined by the limit.
For each number, the program checks whether the number is even or odd by using the modulus operator (n%2).
If the number is even, it is appended to the "even" list, and if the number is odd, it is appended to the "odd" list.
After the for loop completes, the program prints the length of the "even" list and the "odd" list,

which gives the number of even and odd numbers respectively within the given limit.
Expected op:
Enter the Limit :4
Enter the Values :12
Enter the Values :34
Enter the Values :23
Enter the Values :45
Number of Even : 2
Number of Odd : 2"""


limit=int(input("Enter the limit:"))
even=[]
odd=[]
for i in range(1,limit+1):
    num=int(input("Enter the values:"))
    if num%2==0:
        even.append(num)
    else:
        odd.append(num)
print("Number of Even:",len(even))
print("Number of Odd:",len(odd))

