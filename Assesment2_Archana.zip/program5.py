




"""5.Write a program to find the reverse of n digit number using While loop
This program is a simple program that takes an input number from the user and then reverses the number.
It first takes the input number and assigns it to the variable 'num'. Then it initializes a variable 'sum' to 0.
The program enters a while loop where it takes the remainder of the input number when divided by 10 and assigns it to the variable 'rem'.
The variable 'sum' is then updated with the product of its current value and 10, and the remainder obtained from the previous step is added to it.
The input number is then updated to its quotient when divided by 10. The while loop continues to execute until the input number becomes 0.
After the while loop, the program prints the original number and the reversed number obtained from the above process.
Expected op:
Enter the Number :537458
Before Number : 537458
Reverse Number : 854735"""


# Get input from the user
num = int(input("Enter the Number: "))

# Store the original number for printing later
original_num = num

# Initialize the variable to store the reversed number
sum = 0

# Calculate the reverse of the number
while num > 0:
    # Get the last digit of the number
    rem = num % 10

    # Update the reverse number by adding the last digit
    sum = sum * 10 + rem

    # Remove the last digit from the number
    num //= 10

# Print the original and reversed numbers
print("Before Number:", original_num)
print("Reverse Number:", sum)
