num=int(input("Enter the number:"))

def find_prime(num):
	sum=1
	for i in range (1,num):
		if num%i==0:
			sum+=1
		if sum==2:
			return f'{num} is a prime number'
		else:
			return f'{num} is not a prime number'
			
x = find_prime(num=num)
print(x)
