num=int(input("Enter the number:"))
def find_strong_number(num):
	sum=0
	a=num
	while num>0:
		rem=num%10
		fact=1
		for i in range(1,rem+1):
			fact=fact*i
			sum=sum+fact
			num=num//10
		if sum==a:
			return f'{a} is a strong number'
		else:
			return f'{a} is not a strong number'
	    
x = find_strong_number(num=num)
print(x)
