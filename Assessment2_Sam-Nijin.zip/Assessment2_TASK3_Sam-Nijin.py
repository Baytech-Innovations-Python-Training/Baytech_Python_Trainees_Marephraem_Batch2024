num=int(input("ENTER THE NUMBER:"))

def find_armstrong_value(number):
	sum=i=0
	while i<number:
	    rem=(number%10)**3
	    sum=sum+rem
	    number=number//10
	   
	if sum==num:
	    return f'{num} is an armstrong number'
	else:
	    return f'{num} is not an armstrong number'
	    
	    
x=find_armstrong_value(number=num)
print(x)
