def count_even_odd(l):
	even= []
	odd=[]
	for i in range(l):
		n=int(input("Enter the number:"))
		if n%2==0:
			even.append(n)
		else:
			odd.append(n)
	return even, odd
	
limit=int(input('Enter limit : '))
	
even, odd=count_even_odd(l=limit)
print(f'Number of even: {len(even)}\nNumber of odd: {len(odd)}')
