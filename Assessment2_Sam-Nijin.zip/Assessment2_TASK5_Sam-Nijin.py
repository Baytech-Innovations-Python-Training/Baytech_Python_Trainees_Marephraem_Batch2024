num=int(input("Enter the number:"))
def return_numbers(num):
	sum=0
	number=num
	while number>0:
	    rem=number%10
	    sum=(sum*10)+rem
	    number=number//10
	return sum
	
print("Before Number ",num)
print("After Number ",return_numbers(num=num))
