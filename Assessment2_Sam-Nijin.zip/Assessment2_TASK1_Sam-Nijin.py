x=int(input("Enter the number:"))

# Defining function
def find_divisibility(x):
	for i in range(1,x+1):
		if x%i==0:
			print(i)


# Invoking function

find_divisibility(x=x)
