#Youngest Age of Three Program in Python
Ram=input("Enter the Age of Ram:")
Shyam=input("Enter the Age of Shyam:")
Ajay=input("Enter the Age of Ajay:")
if Ram<Shyam and Ajay:
    print("The Youngest Age is Ram")
elif Shyam<Ram and Ajay:
    print("The Youngest Age is Shyam")
else:
    print("The Youngest Age is Ajay")