#Profit Loss Program in Python
costprice=float(input("Enter the cost Price of an Item:"))
sellingprice=float(input('Enter the Selling Price of an Item:'))
if sellingprice>costprice:
    print("Profit:",sellingprice-costprice)
elif costprice>sellingprice:
    print("Loss:",costprice-sellingprice)
elif costprice==sellingprice:
    print("No Profit No Loss")