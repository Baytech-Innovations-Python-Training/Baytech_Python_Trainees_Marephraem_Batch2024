#Program to Find the city temperature
temperature=float(input("Enter the Temperature:"))
b=(temperature-32)*(5/9)
print("Temperature in Centigrade=",b)