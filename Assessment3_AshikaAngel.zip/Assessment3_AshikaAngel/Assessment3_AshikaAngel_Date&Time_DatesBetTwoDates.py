"""Program to print no.of days between two days"""
import datetime as dt
date=dt.date(2023,6,25)
today=dt.date.today()
days=today-date
print(days)