"""Program to reverse the string if it is  multiple of 6"""
name=input("Enter your name:")
a=len(name)
c=0
if(a%6==0):
    name=name[-1::-1]
    print("Reverse name:",name)
    c=1
if(c==1):
    print(" ")
else:
    print("Name cann't be reversed..")