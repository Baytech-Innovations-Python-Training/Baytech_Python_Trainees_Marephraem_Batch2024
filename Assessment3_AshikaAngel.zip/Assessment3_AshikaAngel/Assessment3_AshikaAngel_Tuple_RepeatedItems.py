"""Program to find the repeated items in the tuple"""
l1=[]
l2=[]
c=0
limit=int(input("Enter the limit of elements in the tuple:"))
for i in range(limit):
    l1.append(input("Enter the item name of tuple1:"))
    l2.append(input("Enter the item name of tuple2:"))
t1=tuple(l1)
t2=tuple(l2)
print("Tuple1 contains:",t1)
print("Tuple2 contains:",t2)
for j in range(len(t1)):
    if(t1[j] in t2):
        print(t1[j],"is contained in both tuple...")
        c=1
if(c==1):
    print(" ")
else:
    print("No matching items in both tuple..")
