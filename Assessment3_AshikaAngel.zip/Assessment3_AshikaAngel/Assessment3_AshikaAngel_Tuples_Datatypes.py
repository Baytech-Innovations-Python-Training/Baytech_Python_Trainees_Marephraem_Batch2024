"""Program to create tuples with differentt datatypes"""
content=[]
limit=int(input("Enter the limit of the tuples:"))
for i in range(limit):
    content.append(input("Enter the name of any things you have:"))
    content.append(int(input("Enter the quantity of the thing:")))
    content.append(float(input("Enter the rate of the thing:")))
result=tuple(content)
print("Your input is:",result)