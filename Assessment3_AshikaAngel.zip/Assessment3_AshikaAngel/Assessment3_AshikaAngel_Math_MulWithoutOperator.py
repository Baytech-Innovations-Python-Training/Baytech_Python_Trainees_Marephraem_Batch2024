"""Program to multiply numbers without * operator"""
sum=0
num1=int(input("Enter the number1:"))
num2=int(input("Enter the number2:"))
for i in range(num2):
    sum=sum+num1
print(sum)