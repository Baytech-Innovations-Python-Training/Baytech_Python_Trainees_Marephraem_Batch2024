"""Program to find largest number in the list"""
num=[]
limit=int(input("Enter the limit:"))
for i in range(limit):
    num.append(int(input("Enter the number:")))
max=num[0]
for j in range(len(num)):
    if(max<num[j]):
        max,num[j]=num[j],max
print("The largest number is:",max)