"""Program to find sum of items in the list"""
items=[]
num=[]
sum=0
limit=int(input("Enter the no of items in number:"))
for i in range(limit):
    items.append(input("Enter the item name:"))
    quantity=(int(input("Enter the quantity of each items:")))
    num.append(quantity)
    sum=sum+quantity
print(items)
print(num)
print("Total no of item=",sum)