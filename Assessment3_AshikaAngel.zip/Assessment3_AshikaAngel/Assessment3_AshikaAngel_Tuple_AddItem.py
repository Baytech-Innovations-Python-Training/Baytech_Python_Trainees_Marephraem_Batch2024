"""Program to add items to the list"""
student=("Ashi","Emma","Dephi","Jini")
print("Students are:",student)
students=list(student)
limit=int(input("Enter the no of names you want to add to the tuple:"))
for i in range(limit):
    students.append(input("Enter the name:"))
student=tuple(students)
print("The editted tuple is:",student)