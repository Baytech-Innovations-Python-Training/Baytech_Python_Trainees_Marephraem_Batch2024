"""Program to find if there is common members between to groups"""
first_members=[]
second_members=[]
name=0
limit=int(input("Enter the limit of members:"))
print("Enter the First group members name..")
for a in range(limit):
    first_members.append(input("Enter the name:"))
print("Enter the Seccond group members name..")
for b in range(limit):
    second_members.append(input("Enter the name:"))
print(" ")
for i in range(len(first_members)):
    if(first_members[i] in second_members):
        name=first_members[i]
        print(name,"is a member in both groups")
        name=1
if(name==1):
    print(" ")
else:
    print("No members are common to both groups..")
  
        