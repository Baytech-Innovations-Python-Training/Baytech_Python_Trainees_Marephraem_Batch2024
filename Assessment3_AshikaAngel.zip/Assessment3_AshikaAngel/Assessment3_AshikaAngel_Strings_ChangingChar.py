"""Program to change first and last character in a string"""
string="python"
print("The string is:",string)
first=string.replace("p","M")
second=first.replace("n","m")
print("Editted String is:",second)