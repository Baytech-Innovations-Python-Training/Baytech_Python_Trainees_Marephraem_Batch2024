"""Program to remove nth index character from a string"""
name="Ashika Angel"
print("The string is:",name)
index=int(input("Enter the count of a character to remove it:"))
start=name[:index]
last=name[index+1:]
name=start+last
print(name)