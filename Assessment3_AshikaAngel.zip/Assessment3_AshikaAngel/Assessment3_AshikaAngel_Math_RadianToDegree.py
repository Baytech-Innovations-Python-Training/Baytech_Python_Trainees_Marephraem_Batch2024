"""Program to convert Radian to Degree"""
import math
radian=int(input("Enter the Radian:"))
degree=radian*(180/math.pi)
print("The radian",radian,"in degree is:",degree)