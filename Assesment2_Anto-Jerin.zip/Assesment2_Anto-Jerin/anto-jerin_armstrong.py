num=int(input('enter the number'))
sum=0
a=num
while a>0:
    rem=a%10
    sum +=rem**3
    a//=10
if num==sum:
    print('its a armstrong number')
else:
    print('its not a arm strong number')
    
