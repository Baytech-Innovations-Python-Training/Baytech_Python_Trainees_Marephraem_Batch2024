a=int(input('enter the number'))
b=0
for i in range(2,a):
    if a%i==0:
        b+=1
        break
if b==0:
        print('This is a prime number')
else:
        print('This is not prime number')
