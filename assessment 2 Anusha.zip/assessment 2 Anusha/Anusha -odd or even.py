i=int(input('enter the limit'))
odd=0
even=0
for i in range (0,4):
    n=int(input('enter the value')
    if n%2==0:
      even+=1
    else:
      odd+=1
print('number of even',even)
print('number of odd',odd)
