num=int(input('enter the number'))
a=num
sum=0
while num:
    rem=num%10
    fact=1
    i=1
    while i<=rem:
        
        fact=fact*i
        i=i+1
    sum=fact+sum
    num//=10
if sum==a:
   print(a,'is a strong number')
else:
   print(a,'is not a strong number')

