base=int(input('enter the base number'))
pow=int(input('enter the power number'))
res=1
while pow!=0:
    res*=base
    pow-=1
print('answer='+str(res))
