amount=int(input("enter the amount to be withdrawn"))#amount to be withdrawn
hundred=amount//100
amount=amount%100
print ("number of hundred notes",hundred)#number of hundreds
fifty=amount//50
amount=amount%50
print("number of fifty notes",fifty)#number of fifty
ten=amount//10
print(" number of ten notes")#number of tens

