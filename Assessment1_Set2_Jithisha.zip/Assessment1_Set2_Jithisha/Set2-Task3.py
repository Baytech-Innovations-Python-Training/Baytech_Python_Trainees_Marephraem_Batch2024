#cost price per item
sp=int(input("enter the selling price:"))
profit=int(input("enter the profit:"))
cp=sp-profit
cp=cp//15
print("cost of per item is:",cp)







