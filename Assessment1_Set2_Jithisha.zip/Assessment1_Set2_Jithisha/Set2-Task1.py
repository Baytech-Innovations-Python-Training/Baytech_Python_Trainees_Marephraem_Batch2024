#population
total_population=80000
total_men=52/100*80000
total_women=48/100*80000
percentage_of_total_literacy=48/100*80000
number_of_literate_men=35/100*total_men
number_of_literate_women=13/100*total_women
number_of_non_literate_men=total_men-number_of_literate_men
number_of_non_literate_women=total_women-number_of_literate_women
print("total population is:",total_population)
print("total men is:",total_men)
print("total women is:",total_women)
print("total number of literate men:", number_of_literate_men)
print("total number of literate women:",number_of_literate_women)
print("total non literacy men:",number_of_non_literate_men)
print("total non literacy women:",number_of_non_literate_women)
