#currency program
amt=int(input("enter the amt to be withdrawn:"))
hundred=amt/100
amt=amt%100
fifty=amt/50
ten=amt/10
print("enter the amt to be withdrawn:",amt)
print("number of hundred rupee notes:",hundred)
print("number of fifty rupee notes:",fifty)
print("number of ten rupee notes:",ten)
