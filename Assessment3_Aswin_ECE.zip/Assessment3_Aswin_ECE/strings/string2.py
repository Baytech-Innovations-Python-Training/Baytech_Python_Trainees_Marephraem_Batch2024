#Python program to change a given string to a new string where the first and last chars have been exchanged
Str=input("Enter the String :")
FChar=Str[0]
LChar=Str[-1]
print(LChar+Str[1:-1]+FChar)
