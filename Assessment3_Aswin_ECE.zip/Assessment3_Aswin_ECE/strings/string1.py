#Write a Python program to remove the nth index character from a nonempty string
my_string="hello,world!"
n=3
new_string=my_string[:n]+my_string[n+1:]
print(new_string)
