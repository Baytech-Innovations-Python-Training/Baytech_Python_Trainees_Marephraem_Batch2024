#Write a Python program to get the largest number from a list
my_list=[1,2,3,4,5]
largest_number=max(my_list)
print(largest_number)
