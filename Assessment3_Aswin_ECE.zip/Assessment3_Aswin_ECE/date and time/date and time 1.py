#Write a Python program to get the first and last second
import datetime
now=datetime.datetime.now()
first_second=datetime.datetime(now.year,now.month,now.day,now.hour,now.minute,0,0)
last_second=datetime.datetime(now.year,now.month,now.day,now.hour,now.minute,59,999999)
print("The first second of the current date and time is:",first_second)
print("The last second of the current date abnd time is:",last_second)
