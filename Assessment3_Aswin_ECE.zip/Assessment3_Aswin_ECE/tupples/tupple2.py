#Write a Python program to add an item in a tuple
my_tuple=(1,2,3,4,5)
my_list=list(my_tuple)
my_list.append(6)
my_tuple=tuple(my_list)
print(my_tuple)
