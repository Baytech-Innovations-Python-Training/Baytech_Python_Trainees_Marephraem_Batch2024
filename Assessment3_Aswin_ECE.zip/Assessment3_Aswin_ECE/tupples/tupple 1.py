#Write a Python program to create a tuple with different data types
my_tuple=("apple",1,True,4.5)
print(my_tuple)
