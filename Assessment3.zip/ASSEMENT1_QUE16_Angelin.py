# Example dictionary
dicts = {'a': 1, 'b': 2, 'c': 3}

# Key to check
keys = input("enter the key to check:")

# Checking if key exists
if keys in dicts:
    print(f"The key '{keys}' exists in the dictionary.")
else:
    print(f"The key '{keys}' does not exist in the dictionary.")