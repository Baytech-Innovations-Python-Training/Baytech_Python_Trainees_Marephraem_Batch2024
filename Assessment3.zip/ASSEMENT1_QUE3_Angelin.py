# Write a program to find the reverse of n digit number using While loop


i=int(input("enter the sarting number::"))

while i>=1:
    print(i)
    i-=1
