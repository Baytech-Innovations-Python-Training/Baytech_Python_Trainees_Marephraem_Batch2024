# Write a Python program to get the largest number from a list

my_list = []

limit = int(input("Enter the limit:"))

for i in range(limit):
    value = int(input("Enter a value: "))
    my_list.append(value)

print("List:", my_list)

biggest_number = my_list[0]

for num in my_list :
    if num > biggest_number:
        biggest_number = num

print("The biggest number is:", biggest_number)
