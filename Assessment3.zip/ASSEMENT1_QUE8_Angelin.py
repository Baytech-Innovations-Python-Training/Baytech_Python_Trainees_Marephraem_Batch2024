# Write a Python Program to Add Space between Potential Words

#importing regular expression
import re

#prompting the  input string from the user
input_string = input("Enter the string without spaces: ")

# regular expression to add spaces between potential words
output_string = re.sub(r'(?<=.)([A-Z])', r' \1', input_string)

# Print the result
print("Output string with spaces:", output_string)