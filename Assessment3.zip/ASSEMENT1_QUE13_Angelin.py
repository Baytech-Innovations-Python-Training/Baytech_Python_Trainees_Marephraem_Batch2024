tuple = (1, 2, 3, 4, 4, 5)

# Converting tuple to set
result_set = set(tuple)

# Printing the result
print("Original Tuple:", tuple)
print("Converted Set:", result_set)