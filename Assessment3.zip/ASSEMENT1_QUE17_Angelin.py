# Example dictionary
example_dict = {'a': 10, 'b': 20, 'c': 30}

# Calculating the sum of values
total_sum = sum(example_dict.values())

# Printing the result
print("Sum of all values in the dictionary:", total_sum)