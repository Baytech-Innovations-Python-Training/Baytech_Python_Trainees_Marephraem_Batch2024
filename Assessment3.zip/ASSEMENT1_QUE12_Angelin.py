# 12.Sort a tuple of tuples by 2nd item

#tuple
Tuple=((44,9),(76,8),(56,7),(43,6))
print("the original tuple is:",Tuple)

#sort
sorted_tuple=sorted(Tuple,key=lambda x: x[1])

print("the sorted tuple is:",sorted_tuple)