# Example sets
set1 = {1, 2, 3}
set2 = {1, 2, 3, 4, 5}

# Check if set1 is a subset of set2
is_subset = set1 <= set2

# Printing the result
if is_subset:
    print("set1 is a subset of set2")
else:
    print("set1 is not a subset of set2")