# 4.Write a program to find the Fibonacci Series of the given number

# Prompting n
n = int(input("Enter the limit:"))

# Initialization of numbers 0 and 1
a = 0
print(a)  # First number is printed

b = 1

while b <= n:
    c = a + b
    print(c)
    a = b
    b = c




