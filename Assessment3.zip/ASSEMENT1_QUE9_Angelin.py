# 9.Write a Python program to get the 4th element and 4th element from last of a tuple


# decalaring the tuple
tuple_value = (1, 2, 33, 4, 55, 66, 7, 8, 89, 90, 100)

# to extract 4th element from the initial
print("The Fourth Element From First Is:", tuple_value[3])

# to extract 4th element from the last
print("The Fourth Element From Last Is:", tuple_value[-4])
