# Write a Python program to clone or copy a list

#list initalization
list=[]

limit=int(input("enter the limit:"))

#appending values into list
for i in range(limit):
    list.append(input("enter the values:"))
print("The list is:",list)

#copy_list initalization
copy_list=[]

#copy() function
copy_list=list.copy()

#printed the copy_list
print("The clone 0f the list is:",copy_list)