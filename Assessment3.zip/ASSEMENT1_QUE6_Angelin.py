# 6.Write a Python program to remove duplicates from a list

#initialzation of list
a=[]

#prompting the limit
limit=int(input("enter the limit"))

#appending values into list
for i in range (limit):
    list = a.append(int(input("enter the values")))
print("The orginal list is:",a)

#initialization of a new list
new_list=[]
for i in a:
    if i  not in new_list:
        new_list.append(i)

#new list is printed
print("the new list is:",new_list)


