# 11.Write a Python program to convert a tuple to a dictionary

#tuple
Tuple=(("name","angelin"),("age",21),("place","marthandam"))

#convert tuple to dictionary

converted_tuple=dict(Tuple)
print(converted_tuple)

