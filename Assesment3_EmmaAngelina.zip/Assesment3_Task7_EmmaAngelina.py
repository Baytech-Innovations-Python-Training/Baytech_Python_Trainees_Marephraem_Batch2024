# program to remove the nth index character 
str=input("Enter the string:")
index=int(input("Enter the  charactr's index to be removed:"))
new_str=str[:index]+str[index+1:]
print(new_str)
