#Python function to reverses a string if its length is a multiple of 6
def reverse():
    if len(string)%6==0:
        for i in range(len(string)-1,-1,-1):
            print(string[i])
    else:
        print("The given string is not a multiple of 6!!")
  
string=input("Enter the string:")
      
reverse()

