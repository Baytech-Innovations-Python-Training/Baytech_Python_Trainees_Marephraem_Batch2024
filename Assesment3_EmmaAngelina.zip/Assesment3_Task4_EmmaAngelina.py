#create a tuple with different data types
Tuple=[]
limit=int(input("Enter the no.of elements:"))
for i in range(limit):
    Tuple.append((input("Enter the elements:")))
print("The resultant tuple is:",tuple(Tuple))