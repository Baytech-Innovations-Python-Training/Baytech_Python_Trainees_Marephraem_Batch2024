# program to sum all the items in the list
list=[]
sum=0
for i in range(5):
    list.append(int(input("Enter the mark:")))
for j in list:
    sum=sum+j
print("The total is:",sum,"/500" )