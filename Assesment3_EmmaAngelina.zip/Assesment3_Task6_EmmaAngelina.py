#program to find the repeated items of a tuple
Tuple=[]
limit=int(input("Enter the no.of elements:"))
for i in range(limit):
    Tuple.append((input("Enter the elements:")))
print("The resultant tuple is:",tuple(Tuple))
for j in range(len(Tuple)):
    for k in range(j+1,len(Tuple)):
        if Tuple[j]==Tuple[k]:
           print(Tuple[j],"is repeated")