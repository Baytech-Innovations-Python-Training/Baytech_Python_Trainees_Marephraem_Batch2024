#program to convert radian to degree
import math
radian=int(input("Enter the radian:"))
degree=math.degrees(radian)
print("Degree:",degree)