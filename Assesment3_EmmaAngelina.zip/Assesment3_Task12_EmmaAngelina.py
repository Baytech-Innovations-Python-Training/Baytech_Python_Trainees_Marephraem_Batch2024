#calculate a number of days between two dates
import datetime as dt
first_date=dt.date(2023,8,1)
second_date=dt.date(2023,8,29)
delta = second_date - first_date 
print(delta)