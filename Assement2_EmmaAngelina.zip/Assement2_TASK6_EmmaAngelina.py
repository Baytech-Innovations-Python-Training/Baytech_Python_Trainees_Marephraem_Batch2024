#find the given number is strong number
num=int(input("Enter the number:"))
sum=0#initializing sum=0
a=num
while num>0:
    rem=num%10
    fact=1
    for i in range(1,rem+1):
        fact=fact*i
    sum=sum+fact
    num=num//10
if sum==a:
    print(a,"is a strong number")
else:
    print(a,"is not a strong number")