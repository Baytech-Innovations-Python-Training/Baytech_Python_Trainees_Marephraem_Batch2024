#find the given number is perfect number
num=int(input("Enter the number:"))
for i in range(1,num):#for loop ranging from 1 to num-1
  if num%i==0:
   print(i) 