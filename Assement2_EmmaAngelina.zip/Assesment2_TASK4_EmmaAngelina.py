#count and print the number of odd and even numbers
even=[]
odd=[]
l=int(input("Enter the Limit:"))
for i in range(l):
    n=int(input("Enter the number:"))
    if n%2==0:
        even.append(n)
    else:
        odd.append(n)
print("Number of Even:",len(even))
print("Number of Odd:",len(odd))