#find the value of one number raised to the power of
#another
base=int(input("Enter the base number:"))
pow=int(input("Enter the  power number:"))
res=1
while pow>0:
    res=res*base
    pow-=1
print("RESULT",res)