#find the given number is Armstrong number or not

num=int(input("ENTER THE NUMBER:"))
number=num
sum=0
i=0
while i<number:
    rem=(number%10)**3
    sum=sum+rem
    number=number//10
   
if sum==num:
    print(num,"is an armstrong number")
else:
    print(num,"is not an armstrong number")
