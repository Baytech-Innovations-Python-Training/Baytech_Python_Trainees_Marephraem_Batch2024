#Python program to get the largest number from a list
List=[]
limit=int(input("Enter the number of elements that has to be inserted in the list :"))
for i in range(limit):
    List.append(int(input("Enter the elements :")))
for i in range(limit-1):
    if List[i]>List[i+1]:
        GNum=List[i]
    else:
        Gnum=List[i+1]
print("Greatest Number in the list :",Gnum)
