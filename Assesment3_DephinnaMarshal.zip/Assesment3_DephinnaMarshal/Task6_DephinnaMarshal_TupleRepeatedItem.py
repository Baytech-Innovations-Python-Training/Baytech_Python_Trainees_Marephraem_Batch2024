#Python program to find the repeated items of a tuple
tup=[]
list=[]
limit =int(input("Enter the number of elements :"))
for m in range(limit):
    tup.append(input("Enter the Elements :"))
tup1=tuple(tup)
print("Tuple :",tup1)
for i in range(len(tup)):
    for j in range(i):
        if tup[i]==tup[j]:
            list.append(tup[i])
newTup=tuple(list)
print("Repeated item is:",newTup)

