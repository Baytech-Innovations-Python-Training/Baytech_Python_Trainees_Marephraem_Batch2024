#Python program to sum all the items in the list
List=[]
Sum=0
limit=int(input("Enter the number of elements that has to be inserted in the list :"))
for i in range(limit):
    List.append(int(input("Enter the elements :"))) #adding element into a list
print("List :",List)
for  i in range(limit):
    Sum+=List[i]   #summing up each item present inside the given list using
print("Sum :",Sum)