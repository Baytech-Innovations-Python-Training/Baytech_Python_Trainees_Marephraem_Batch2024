#Python program to multiply two integers without using the * operator in python
Num1=int(input("Enter the first Num :"))
Num2=int(input("Enter the second Num :"))
Res=0
for i in range(Num1):
    Res+=Num2
print("Result :",Res)