#Python program to remove the nth index character from a nonempty string
Str=input("Enter the String :")
index=int(input("Enter the index to be removed :"))
print(Str[:index]+Str[index+1:])
