#Python function to reverses a string if its length is a multiple of 6
Str=input("Enter the String :")
if len(Str)%6==0:
    print(Str[::-1])