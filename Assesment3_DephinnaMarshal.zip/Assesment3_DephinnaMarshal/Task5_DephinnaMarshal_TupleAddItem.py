#Python program to create a tuple with different data types
tup=()
tuple1=list(tup) #Casting Tuple into a list
Num=int(input("Enter the number of elements :"))
for i in range(Num):
    tuple1.append(input("Enter the Elements :"))
print(tuple1)
New=input("Enter the new item to add :")
tuple1.append(New)
tup=tuple(tuple1) #Casting List into a tuple
print(tup)