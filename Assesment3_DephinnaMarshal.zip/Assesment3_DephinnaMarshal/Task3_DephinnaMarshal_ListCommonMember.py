#Program that get two lists as input and check if they have at least one common member
List1,List2,List3=[],[],[]
N1=int(input("Enter the number of elements in List 1: "))
N2=int(input("Enter the number of elements in List 2: "))
for i in range (N1):
    List1.append(input("Enter the elements in List 1:"))
for j in range (N2):
    List2.append(input("Enter the elements in List 2: "))
for i in range(N1):
    for j in range(N2):
        if List1[i]==List2[j]:
            List3.append(List1[i])
print("The Common Members are :",List3)

   

