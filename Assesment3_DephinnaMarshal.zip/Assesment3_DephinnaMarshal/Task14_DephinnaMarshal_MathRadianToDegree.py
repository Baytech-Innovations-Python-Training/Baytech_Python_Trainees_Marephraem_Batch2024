#Python program to convert radian to degree
import math
Rad=float(input("Enter the angle in Radian :"))
Deg = Rad * (180 / math.pi)
print("Angle in Radian :",Rad)
print("Angle in Degree :",Deg)