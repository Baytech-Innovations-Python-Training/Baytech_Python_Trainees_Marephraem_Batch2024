#total population
total_population=80000
print("total population",total_population)#total population of men and women
total_men=int(total_population*0.52)#total men
print("total men",total_men)
total_women=total_population-total_men#total women
print("total women",total_women)
total_literacy=int(total_population*0.48)#total literacy
print("total literacy",total_literacy)
total_literate_men=int(total_population*0.35)#total literate men
print("total literate men",total_literate_men)
total_literate_women=total_literacy-total_literate_men#total literate women
print("total literate women",total_literate_women)
total_non_literate_men=total_men-total_literate_men#total non literate men
print("total non literate men",total_non_literate_men)
total_non_literate_women=total_women-total_literate_women#total non literate women
print("total non literate women",total_non_literate_women)