#prompting the Quantity and Amount
qty=int(input("Enter the Quantity Purchased :"))
amt=int(input("Enter the Amount Per Item :"))
if qty>10:#if qty>10 the statements executes
    total_expense=qty*amt
    print("Total Expenses is:",total_expense-total_expense*10/100)#prints it
else:#else if qty<10 
    print("Total Expenses is:",qty*amt)#prints it