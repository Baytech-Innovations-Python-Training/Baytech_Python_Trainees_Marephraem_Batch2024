1.x=int(input("enter the number:"))1.#factor of given number
for i in range(1,x+1):
    if x%i==0:
        print(i)
2.#prime number
n=int(input("enter the number:"))
sum=0
for i in range(1,n+1):
    if n%i==0:
        sum+=1
if sum==2:
    print(n,"is a prime number")
else:
    print(n,"is not a prime number")
3.#armstrong or not
num=int(input("enter the number"))
sum=0
temp=num
while temp>0:
    digit=temp%10
    sum+=digit**3
    temp//=10
if num==sum:
    print(num,"is an armstrong number")
else:
    print(num,"is not an armstrong number")
4.#odd and even
limit=int(input("enter the limit:"))
even=0
odd=0
for i in range(limit):
    value=int(input("enter the value"))
    if value%2==0:
              even+=1
    else:
        odd+=1
print("The number is even",even)
print("The number is odd",odd)
5.#reverse
num=int(input("enter the number"))
print("Before number:",num)
rev=0
while num>0:
    rem=num%10
    rev=(rev*10)+rem
    num=num//10
print("Reverse number:",rev)
6.##find the numberr is strong
num=int(input("Enter the number"))
a=num
sum=0
while num>0:
    rem=num%10
    fact=1
    for i in range(1,rem+1):
        fact=fact*i
    sum=sum+fact
    num=num//10
if sum==a:
    print("The number is a strong number")
else:
    print("The number is not a strong number")
# power
base=int(input("Enter the base"))
power=int(input("Enter the power"))
res=1
while power>0:
    res*=base
    power-=1
print("The result is:",res)
#find the prefet number between 1-1000
for i in range (1,1000):
    if 1000%i==0:
        print(i)
#find the prefect number
num=int(input("Enter the number:"))
for i in range(1,num):
    if num%i==0:
        print(i)
