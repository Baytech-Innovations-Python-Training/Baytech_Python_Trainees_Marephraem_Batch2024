print("CALCULATOR\n1.Addition\n2.Subtraction\n3.Multiplication\n4.Division\n5.Modulo")

#Gathering user input to perform each operations

a=int(input("Select the operation:"))

#using if else im assigning the operations
if a==1:
    x=int(input("Enter the value of X:"))
    y=int(input("Enter the value of Y:"))
    print("Addition of X and Y:",x+y)
elif a==2:
    x=int(input("Enter the value of X:"))
    y=int(input("Enter the value of Y:"))
    print("Subtraction of X and Y:",x-y)
elif a==3:
    x=int(input("Enter the value of X:"))
    y=int(input("Enter the value of Y:"))
    print("Addition of X and Y:",x*y)
elif a==4:
    x=int(input("Enter the value of X:"))
    y=int(input("Enter the value of Y:"))
    print("Addition of X and Y:",x/y)
elif a==5:
    x=int(input("Enter the value of X:"))
    y=int(input("Enter the value of Y:"))
    print("Addition of X and Y:",x%y)
else:
    print("Enter a value between 1 to 7")
 
