amt=int(input("Enter the Amount to be Withdrawn:"))
a=amt//100
amt=amt%100
b=amt//50
amt=amt%50
c=amt//20
amt=amt%20
print(a)
print(b)
print(c)
