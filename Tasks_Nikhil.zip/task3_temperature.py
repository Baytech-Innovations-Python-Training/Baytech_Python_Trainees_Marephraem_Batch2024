#getting a float input
fr=float(input("Fahrenheit:"))

#converting it to celcius

print("Temperature is",(5/9)*(fr-32))
