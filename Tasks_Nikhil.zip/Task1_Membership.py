#Gathering user input
x=int(input("Amount:"))
y=int(input("Day:"))
#Finding fine amount using if else condition
if y==0:
	print("Amount:",x)
elif y>=1 and y<=5:
	print("Amount with fine:",x+(y*5))
elif y>=6 and y<=10:
	print("Amount with fine:",x+(y*15))
elif y>=11 and y<=30:
	print("Amount with fine:",x+(y*15))
else:
	print("Membership Suspended")
