total=int(input("Total:"))

x=int(input("Total Literacy percentage:"))

y=int(input("Men Percentage:"))

z=int(input("Men Literacy percentage:"))

a=x-z

b=total-y
#Output
print("\n")
print("RESULTS")
print("\n")
print("Total population:80000")
print("Total population percentage:",total)
print("Total Literacy percentage:",x)
print("Total Percentage Men:",y)
print("Total Percentage Women:",b)
print("Men Literacy percentage:",z)
print("Women Literacy percentage:",a)
print("Iliteracy percentage:",total-x)
print("Men Iliteracy percentage:",y-z)
print("Women Iliteracy percentage:",b-a)
