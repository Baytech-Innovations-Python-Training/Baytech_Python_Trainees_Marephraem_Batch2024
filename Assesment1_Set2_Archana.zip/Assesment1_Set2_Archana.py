#1

totalpopulation=80000
totalmen=(52/100)*80000
totalwomen=80000-totalmen
totalliterate=(48/100)*80000
literatemen=(35/100)*totalliterate
literatewomen=totalliterate-literatemen
nonliteratemen=totalmen-literatemen
nonliteratewomen=totalwomen-literatewomen
print("Total Population :",totalpopulation)
print("Total Mens :",totalmen)
print("Total Womens :",totalwomen)
print("Total Literacy :",totalliterate)
print("Total Literacy Mens :",literatemen)
print("Total Literacy Womens :",literatewomen)
print("Total Not Literacy Mens :",nonliteratemen)
print("Total Not Literacy Womens :",nonliteratewomen)





#2
amt=int(input("Enter the amount to be withdrawn:"))
quotient=amt//100
hundred=quotient
remainder=amt%100
amt=remainder
quotient=amt//50
fifty=quotient
remainder=amt%50
amt=remainder
quotient=amt//10
ten=quotient
print("No. of hundred notes:",hundred)
print("No. of fifty notes:",fifty)
print("No. of ten notes:",ten)




#3
sp=int(input("Enter the selling price:"))
profit=int(input("Enter the profit:"))
cp=sp-profit
quotient=cp//15
cp=quotient
print("cost price of per item:",cp)
