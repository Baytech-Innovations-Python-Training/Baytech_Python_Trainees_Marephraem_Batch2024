#Python program for remove nth index of the string from the non-empty string
def remove(string,n):
    first=string[:n]
    last=string[n+1:]
    return first+last
string=input("Enter the string:")
n=int(input("Enter the nth index string:"))
print("Modified String")
print(remove(string,n))

#Python program to change a given to a new string where the first and last chars exchanged
def swap(string):
    start=string[0]
    end=string[-1]
    return end+string[1:-1]+start
string=input("Enter the string:")
print(swap(string))

#Python program to reverses a string if its length is a multiple of 6
def reverse(string):
    if len(string) % 6 == 0:
     return''.join(reversed(string))
    return(string)
string = input("Enter the string:")
print(reverse(string))


