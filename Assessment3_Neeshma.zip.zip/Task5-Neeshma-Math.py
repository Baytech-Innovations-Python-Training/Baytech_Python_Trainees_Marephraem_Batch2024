#Python program for smallest multiple of first n number and display factor
import math
a=int(input("Enter the number1:"))
b=int(input("Enter the number2:"))
c=int(input("Enter the number3:"))
lcm=math.lcm(a,b,c)
print("The factor is",lcm)

#Python program for convert radian to degree
import math
a=int(input("Enter the number:"))
result=math.degrees(a)
print("The degree is",result)


#Python program to multiple two numbers without using the * operator
import math
a=int(input("Enter the number1:"))
b=int(input("Enter the number2:"))
c=int(input("Enter the number3:"))
result=(a,b,c)
print(math.prod(result))
