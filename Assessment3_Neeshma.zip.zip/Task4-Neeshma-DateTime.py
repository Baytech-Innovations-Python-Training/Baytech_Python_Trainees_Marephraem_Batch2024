#Python Program to get the first and last second
import datetime
print("First_second",datetime.time.min)
print("last_second",datetime.time.max)

#Python program to get a date of the last tuesday
from datetime import date
from datetime import timedelta
today=date.today()
offset=(today.weekday()-1)%7
last_tue=today-timedelta(days=offset)
print(last_tue)

#Python program to calculate number of days between two dates
import datetime as dt
current_date=dt.date.today()
new_day=dt.date(2023,6,6)
print("No of days between two dates",current_date-new_day)