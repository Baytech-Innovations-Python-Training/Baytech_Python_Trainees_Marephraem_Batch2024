#Python program to sum all the items
list=[]
Total=0
limit=int(input("Enter the limit:"))
for i in range(limit):
   Item =int(input(f"Enter the Item{i+1}:"))
   list.append(Item)
print(list)
for i in range(0,limit):
    Total= Total+Item
print("The sum of all items is",Total)


#Python program to get a largest number from a list
list=[]
limit=int(input("Enter the limit:"))
for i in range(limit):
   Number =int(input(f"Enter the Number{i+1}:"))
   list.append(Number)
print(list)
for i in list:
   list.sort()
print(list[-1])


#Python Program for creating two list and check one common number
list=[]
list1=[]
limit=int(input("Enter the limit:"))
for x in range(limit):
   Number =int(input(f"Enter the Number{x+1}:"))
   list.append(Number)
print(list)
for y in range(limit):
   Number1 =int(input(f"Enter the Number{y+1}:"))
   list1.append(Number1)
print(list1)
if x==y:
   print("True,List have atleast one common member")
else:
   print("False,List don't have  atleast one common member")