#Python program for Creating a tuple of different data types
list=[]
limit=int(input("Enter the limit:"))
for i in range(limit):
    list.append(input(f"Enter the  value{i + 1}:"))
print(tuple(list))

#Python program to add item in a tuple
list=[]
limit=int(input("Enter the limit:"))
for i in range(limit):
    list.append(input(f"Enter the  Item{i + 1}:"))
    list.append("Rs.20")
print(tuple(list))

#Python program for finding the repeated item of a tuple
list=[]
limit=int(input("Enter the limit:"))
for i in range(limit):
    list.append(input(f"Enter the  value{i+1}:"))
print(tuple(list))
for i in list:
 if list.count(i)>1:
  print("Tuple is repeated",i)


