"""Program to find the population of men ,women and literacy rate"""
total_population=80000
total_men=total_population*0.52
total_women=total_population-total_men
total_literacy=total_population*0.48
literate_men=total_literacy*0.35
literate_women=total_literacy-literate_men
not_literate_men=total_men-literate_men
not_literate_women=total_women-literate_women
print("Total Population:",total_population)
print("Total Mens:",total_men)
print("Total Womens:",total_women)
print("Total Literacy:",total_literacy)
print("Total Literacy Mens:",literate_men)
print("Total Literacy Womens:",literate_women)
print("Not Literacy Mens:",not_literate_men)
print("Not Literacy Womens:",not_literate_women)