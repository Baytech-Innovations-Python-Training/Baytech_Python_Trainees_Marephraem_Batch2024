"""To find cost of an item from the profit earned"""
sp=int(input("Enter the selling price:"))
profit=int(input("Enter the profit:"))
cp=profit-sp
cp=cp//15
print("The cost price of per item:",cp)