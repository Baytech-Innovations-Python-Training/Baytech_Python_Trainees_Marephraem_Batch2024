"""Program to find the number of currency to withdraw"""
amt=int(input("Enter the amount to be withdraw:"))
hundred=amt//100
print("No of Hundred rupee notes",hundred)
amt=amt%100
fifty=amt//50
print("No of Fifty rupee notes:",fifty)
amt=amt%50
ten=amt//10
print("No of Ten rupee note:",ten)