Gender=input("Enter the Gender(Male,Female):")
Year=int(input("Enter the year of Service:"))
Qualification=input("Enter the Qualification(Graduate(0),Post-Graduate(1)):")
if  Gender=="Male" and Year >=10 and Qualification=="Post-Graduate(1)" :
    print( "Salary : 15000")
elif Gender=="Male" and Year >=10 and Qualification=="Graduate(0)":
    print("Salary : 10000")
elif Gender=="Male" and Year  < 10 and Qualification == "Post-Graduate(1)" :
    print("Salary : 10000")
elif Gender=="Male" and Year  < 10 and Qualification == "Graduate(0)":
    print("Salary : 7000")
elif Gender == "Female" and Year >=10 and Qualification=="Post-Graduate(1)":
  print("Salary : 12000")
elif Gender == "Female" and  Year >=10 and Qualification=="Graduate(0)":
    print("Salary : 9000")
elif Gender == "Female" and Year < 10 and Qualification == "Post-Graduate(1)":
    print("Salary : 10000")
elif Gender == "Female" and Year  < 10 and Qualification == "Graduate(0)":
    print("Salary : 6000")
else:
    print("Invalid data")
