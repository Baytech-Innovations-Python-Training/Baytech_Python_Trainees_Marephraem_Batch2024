qty=int(input("Enter the Quantity purchased"))
amt=int(input("Enter the Amount per item"))
if(qty>10):
    total=qty*amt
    total=total-(total*10/100)
else:
    total=qty*amt
print("Enter the Quantity Purchased",qty,"\nEnter the Amount Per Item",amt,"\nTotal expense is",total)

