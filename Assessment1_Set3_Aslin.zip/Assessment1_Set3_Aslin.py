 #Task1
#Total expenses program
name=input("enter the name:")
qty=int(input("enter the quantity:"))
amt=int(input("enter the amount:"))
if(qty>10):
    totalexpense=qty*amt
    print("totalexpenses:",totalexpense-totalexpense*10/100)
else:
    print("totalexpense",qty*amt)
#Output
enter the name:ammu
enter the quantity:14
enter the amount:78
totalexpenses: 982.8
                        #Task2
#company insures drivers program
name=input("enter the name:")
age=int(input("enter the age:"))
gender=input("enter the gender:")
marital_status=input("enter the marital_status:")
if(marital_status=="US"):
    print("driver should be insured")
elif (marital_status=="U"and age>30 and gender=="M"):
  print("driver should be insured")
elif(marital_status=="U"and age>25 and gender=="F"):
   print("driver should be insured")
else:
 print("driver should not be insured")
 #output
enter the name:Ammu
enter the age:21
enter the gender:F
enter the marital_status:U
driver should not be insured
                   #Task3
#salary program
gender=input("enter the gender:")
year=int(input("enter the year:"))
level=int(input("enter the level:"))
if gender=="m":
 if year>=10 and level==1:
      print("salary:15000")
 elif year>=10 and level==0:
    print("salary:10000")
 elif year<10 and level==1:
    print("salary:10000")
 else:
     print("salary:7000")
if gender=="f":
 if year>=10 and level==1:
    print("salary:12000")
 elif year>=10 and level==0:
    print("salary:9000")
 elif year<10 and level==1:
    print("salary:10000")
 else:
     print("salary:6000")
#output
enter the gender:m
enter the year:10
enter the level:0
salary:10000
    

