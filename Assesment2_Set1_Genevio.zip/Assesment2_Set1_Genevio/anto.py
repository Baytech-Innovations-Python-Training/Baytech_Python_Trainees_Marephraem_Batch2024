a=float(input("cost_price"))#a=cost_price
b=float(input("selling_price"))#b=selling_price
if a>b:
    print("loss",a-b)
elif a<b:
    print("profit",b-a)
elif a==b:
    print("No Profit No Loss")