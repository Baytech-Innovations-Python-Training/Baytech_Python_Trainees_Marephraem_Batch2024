a=int(input("age of Ram"))#a=age of ram
b=int(input("age of Shyam"))#b=age of shyam
c=int(input("age of Ajay"))#c=age of ajay
if a<b<c:
    print("The Youngest Age is Ram")
elif b<a<c:
    print("The Youngest Age is Shyam")
elif c<a<b:
    print("The Youngest Age is Ajay")
