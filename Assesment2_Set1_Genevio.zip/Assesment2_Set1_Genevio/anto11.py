F=float(input("Enter the Temperature"))#F=fahrenheit
C=(F-32)*5/9#C=celsius
print(C)