#program to find the city temperature

fr=float(input("Enter the Temperature :"))

sub=fr-32
cent=sub*5/9

print("Temperature in Centigrade =",cent)