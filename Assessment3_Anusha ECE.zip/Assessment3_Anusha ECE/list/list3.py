#Write a Program that get two lists as input and check if they have at least one common member
list1=[1,2,3,4,5]
list2=[5,6,7,8,9]
common_member=set(list1).intersection(list2)
if common_member:
   print("The list have at least one common member.,")
else:
     print("The list do not have any common members.")
