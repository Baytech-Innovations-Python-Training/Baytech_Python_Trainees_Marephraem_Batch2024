#write a python program to sum all the items
my_list=[1,2,3,5]
sum_of_list=sum(my_list)
print(sum_of_list)
