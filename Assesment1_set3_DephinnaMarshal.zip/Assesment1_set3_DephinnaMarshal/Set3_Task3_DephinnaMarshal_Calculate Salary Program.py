#prompts Gender,Years of service,Qualification
Gender=input("Enter the Gender f/m :")
Years_of_service=int(input("Enter the Years of Service :"))
Qualification=int(input("Enter the Qualification (Graduate(0) , Post-Graduate(1)) :"))
#if condition to check gender m
if Gender=="m":
    if Years_of_service>=10 and Qualification==1:
        print("Salary :15000")
    elif Years_of_service>=10 and Qualification==0:
        print("Salary :10000")
    elif Years_of_service<10 and Qualification==1:
        print("Salary :10000")
    else:
        print("Salary :7000")
#if condition to check gender f
if Gender=="f":
    if Years_of_service>=10 and Qualification==1:
        print("Salary :12000")
    elif Years_of_service>=10 and Qualification==0:
        print("Salary :9000")
    elif Years_of_service<10 and Qualification==1:
        print("Salary :10000")
    else:
        print("Salary :6000")