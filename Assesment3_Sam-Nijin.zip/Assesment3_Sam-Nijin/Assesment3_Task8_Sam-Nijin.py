# program to change a given string to a new string where the first and last chars have been exchanged
str=input("Enter the string:")
a=str[0]
b=str[len(str)-1]
new_str=b+str[1:len(str)-1]+a
print(new_str)

