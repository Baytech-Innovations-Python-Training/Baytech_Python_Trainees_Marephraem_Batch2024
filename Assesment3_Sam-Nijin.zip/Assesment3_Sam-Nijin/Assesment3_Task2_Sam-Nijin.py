#program to get the largest number from a list
list=[]
largest=0
limit=int(input("Enter the no.of elements:"))
for i in range(limit):
    list.append(int(input("Enter the number:")))
for j in list:
    if j>largest:
        largest=j
print("The largest number from a list is:",largest)
