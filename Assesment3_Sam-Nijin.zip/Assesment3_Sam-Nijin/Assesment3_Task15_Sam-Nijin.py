#program to multiply two integers without using the * operator 

a = int(input("Enter the first integer: "))
b = int(input("Enter the second integer: "))
mul=a
for i in range(b-1):
  mul=mul+a
print(a,"*",b,"=",mul)
