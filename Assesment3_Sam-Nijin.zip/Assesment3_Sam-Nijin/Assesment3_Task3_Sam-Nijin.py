#at leastone common member
list_1=[]
list_2=[]
limit=int(input("Enter the no.of elements:"))
print("Elements in the first list!!")
for i in range(limit):
    list_1.append((input("Enter the name of the member:")))
print("Elements in the second list!!")
for i in range(limit):
    list_2.append((input("Enter the name of the member:")))
for j in list_1:
    for k in list_2:
        if j==k:
            print(j,"is the common member in both the list")

