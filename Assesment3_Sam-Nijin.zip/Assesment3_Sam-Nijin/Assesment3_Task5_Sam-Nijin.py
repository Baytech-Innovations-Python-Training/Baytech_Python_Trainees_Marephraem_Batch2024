# program to add an item in a tuple
Tuple=[]
limit=int(input("Enter the no.of elements:"))
for i in range(limit):
    Tuple.append((input("Enter the elements:")))
print("The resultant tuple is:",tuple(Tuple))
index=int(input("Enter the index num where you want to add an item:"))
Tuple[index]=input("Enter the item:")
print("The altered tuple:",tuple(Tuple))