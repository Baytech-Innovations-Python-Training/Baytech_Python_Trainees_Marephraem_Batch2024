
                            #list


#1.Write a Python program to sum all the items
a=[10,20,30,40,5]
b=0
for i in range(5):
    c=b+a[i]
    b=c
print(b)


#2.Write a Python program to get the largest number from a list
d=[5,1,9,2,8,4,12,6]
e=0
for i in range(8):
    f=d[i]
    if f>e:
        e=f
print(e)



#3.Write a Program that get two lists as input and check if they have at least one common member
g=[]
h=[]
l=0
for i in range(5):
    j=input(f"Enter the birds name{i+1}:")
    g.append(j)
    k=input(f"Enter the animals name{i+1}:")
    h.append(k)
print(list(g))
print(list(h))
for i in range(5):
    if g[0]==h[i]:
        l=l+1
    elif g[1]==h[i]:
        l=l+1
    elif g[2]==h[i]:
        l=l+1
    elif g[3]==h[i]:
        l=l+1
    elif g[4]==h[i]:
        l=l+1
if l==1:
    print("They have common member")
if l==0:
    print("They haven't common member")








    
