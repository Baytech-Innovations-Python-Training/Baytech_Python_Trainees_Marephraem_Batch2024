
                                      #Date and Time


#1.Write a Python program to get the first and last second
from datetime import datetime, timedelta
def get_first_and_last_second_of_day():
    now = datetime.now()
    # Get the first second of the day
    first_second = now.replace(hour=0, minute=0, second=0, microsecond=0)
    # Get the last second of the day
    last_second = now.replace(hour=23, minute=59, second=59, microsecond=999999)
    return first_second, last_second
# Test the function
if __name__ == "__main__":
    first_sec, last_sec = get_first_and_last_second_of_day()
    print("First second of the day:", first_sec)
    print("Last second of the day:", last_sec)




#2.Write a Python program to get the date of the last Tuesday
import datetime
def get_last_tuesday_date():
    today = datetime.date.today()
    days_to_subtract = (today.weekday() - 1) % 7  # Tuesday is represented by 1 in the weekday() function
    last_tuesday = today - datetime.timedelta(days=days_to_subtract)
    return last_tuesday
last_tuesday_date = get_last_tuesday_date()
print("Date of the last Tuesday:", last_tuesday_date)



#3.Write a Python program to calculate a number of days between two dates
from datetime import datetime
def calculate_days_between_dates(start_date, end_date):
    date_format = "%Y-%m-%d"
    start_date_obj = datetime.strptime(start_date, date_format)
    end_date_obj = datetime.strptime(end_date, date_format)
    delta = end_date_obj - start_date_obj
    return delta.days
# Test the function
if __name__ == "__main__":
    start_date = input("Enter the start date (YYYY-MM-DD): ")
    end_date = input("Enter the end date (YYYY-MM-DD): ")
    days_between_dates = calculate_days_between_dates(start_date, end_date)
    print("Number of days between the dates:", days_between_dates)

