

#1.Write a Python program to remove the nth index character from a nonempty string

def remove_nth_character(string, n):
    if n >= len(string) or n < 0: # Check if n is a valid index within the string length
        return "Invalid index!"
    result = string[:n] + string[n + 1:]# Remove the nth character from the string
    return result
input_string = input("Enter a nonempty string: ")
index_to_remove = int(input("Enter the index of the character to remove: "))
result_string = remove_nth_character(input_string, index_to_remove)
print("Result:", result_string)





#2.Write a Python program to change a given string to a new string where the first and last chars have been exchanged
def exchange_first_and_last(string):
    first_char = string[0]
    last_char = string[-1]
    new_string = last_char + string[1:-1] + first_char
    return new_string
input_string = input("Enter a string: ")
result_string = exchange_first_and_last(input_string)
print("Result:", result_string)


#3.Write a Python function to reverses a string if its length is a multiple of 6

def reverse_string_if_multiple_of_6(input_string):
    if len(input_string) % 6 == 0:
        return input_string[::-1]
    else:
        return input_string
input_string = input("Enter a string: ")
result_string = reverse_string_if_multiple_of_6(input_string)
print("Result:", result_string)












