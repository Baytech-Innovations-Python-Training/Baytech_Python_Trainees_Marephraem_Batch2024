
                                                       #Math


#1.Write a Python program to find the smallest multiple of the first n numbers. Also, display the factors
def find_smallest_multiple(n):
    def gcd(a, b):
        while b:
            a, b = b, a % b
        return a
    def lcm(a, b):
        return (a * b) // gcd(a, b)
    if n < 1:
        print("Invalid input. n should be a positive integer.")
        return
    smallest_multiple = 1
    for i in range(2, n + 1):
        smallest_multiple = lcm(smallest_multiple, i)
    factors = []
    for i in range(1, smallest_multiple + 1):
        if smallest_multiple % i == 0:
            factors.append(i)
    return smallest_multiple, factors
# Test the function
if __name__ == "__main__":
    n = int(input("Enter a positive integer n: "))
    result, factors = find_smallest_multiple(n)
    if result:
        print(f"The smallest multiple of the first {n} numbers is: {result}")
        print("Factors:", factors)





#2.Write a Python program to convert radian to degree
import math
def radian_to_degree(radians):
    degrees = radians * (180 / math.pi)
    return degrees
# Test the function
if __name__ == "__main__":
    radian = float(input("Enter the value in radians: "))
    degree = radian_to_degree(radian)
    print(f"{radian} radians is equal to {degree} degrees.")





#3.Write a Python program to multiply two integers without using the * operator in python
def multiply_without_operator(a, b):
    result = 0
    if b < 0:
        a, b = b, a
    for _ in range(abs(b)):
        result += a
    return result
# Test the function
if __name__ == "__main__":
    num1 = int(input("Enter the first integer: "))
    num2 = int(input("Enter the second integer: "))
    product = multiply_without_operator(num1, num2)
    print(f"The product of {num1} and {num2} is: {product}")

