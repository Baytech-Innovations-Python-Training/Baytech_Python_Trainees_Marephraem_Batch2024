
                                           #tuples



#1.Write a Python program to create a tuple with different data types

a=1,2,3,4
b="This is my program"
c=4.0,2.0,3.0
d=[1,2,3,4]
print(tuple(a))
print(tuple(b))
print(tuple(c))
print(tuple(d))





#2.Write a Python program to add an item in a tuple
data=("apple","123","mango")
data=list(data)
data.append(456)
data=tuple(data)
print(data)




#3.Write a Python program to find the repeated items of a tuple

g=(1,2,3,2,4)
for i in range(0,1):
    if g[i]==g[1]:
        print("the repeated items is",g[i])
    elif g[i]==g[2]:
        print("the repeated items is",g[i])
    elif  g[i]==g[3]:
        print("the repeated items is",g[i])
    elif  g[i]==g[4]:
        print("the repeated items is",g[i])
for i in range(1,2):
    if g[i]==g[2]:
        print("the repeated items is",g[i])
    elif g[i]==g[3]:
        print("the repeated items is",g[i])
    elif  g[i]==g[4]:
        print("the repeated items is",g[i])
for i in range(2,3):
    if g[i]==g[3]:
        print("the repeated items is",g[i])
    elif  g[i]==g[4]:
        print("the repeated items is",g[i])
for i in range(3,4):
    if g[i]==g[4]:
        print("the repeated items is",g[i])
   












